package com.dapeng.util;

import java.util.Timer;
import java.util.TimerTask;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo.State;
import android.os.Handler;

public class Util {
	
		public static Handler uiHandler;//��紫���handler�����ͽ��潻��
		public static Handler gzHandler;//����
		public static Handler trsdHandler;//�ؼ�ģʽ
		public static Handler ljHandler;//���ģʽ
		public static Handler wdHandler;//������
		public static Handler sdHandler;//��������
		//�����ý��洫��
		public static int rate = 9600, stopBit=1,jiou=0,dataBits=8;
		//���ڵ�ַ
		public static int addr1,addr2;
		public static String whichBlock = "30";//�������˲�ͬ�İ����ź�  Ĭ����30
		public static String gzwhichBlock = "30";//�������˲�ͬ�İ����ź�  Ĭ����30
		public static String wdwhichBlock = "30";//�������˲�ͬ�İ����ź�  Ĭ����30
		public static String sdwhichBlock = "30";//�������˲�ͬ�İ����ź�  Ĭ����30
		public static String trsdwhichBlock = "30";//�������˲�ͬ�İ����ź�  Ĭ����30
		public static String ljwhichBlock = "30";//�������˲�ͬ�İ����ź�  Ĭ����30
		public static String IP = "http://hcj335171.x9.fjjsp01.com/";
		public static final int NETADRR = 1000;
	    public static final int NETNUM = 1100;
	    public static final int SINGLENUM = 1200;
	    public static final int ALLDATA = 1300;
	    public static final int FDDATA = 1400;
	    public static final int FCDATA = 1500;
	    public static final int USBCONN = 1600;
	    
	    public static final int STOP = 10;
	    public static final int START = 20;
	    public static final int RESTART = 30;
	    public static final int STOPALL = 40;
	    public static final int CLOSELIGHT = 50;
	    public static final int OPENLIGHT = 60;
	    public static final int CHANGECANSHU = 70;
	    public static final int WRITEDATA = 80;
	    
	    public static final int DSONE1OPEN = 81;
	    public static final int DSONE2OPEN1 = 82;
	    public static final int DSONE2OPEN2 = 83;
	    public static final int DSONE2FAN = 84;
	    public static final int DSONE2ZHENG = 85;
	    public static final int DSONE3OPEN = 86;
	    public static final int DSONE4OPEN = 87;
	    public static final int DSONE5OPEN = 88;
	    
	    public static final int DSONE2BT1 = 89;
	    public static final int DSONE2BT2 = 90;
	    public static final int DSONE2BT3 = 91;
	    
	    public static final int DSTWO1OPEN = 101;
	    public static final int DSTWO1QUEDING = 102;
	    
	    public static final int DSTWO4OPEN = 103;
	    public static final int DSTWO5OPEN = 104;
	    public static final int JIAJU=105;
	    public static String boxNum = "";
//	    public static String box_num = "";
	    public static boolean hongwaiNum = false;
	    public static boolean yanwuNum = false;
	    public static boolean zhendongNum = false;
	    public static boolean liandongNum = false;
	    public static boolean isControl = false;
	    public static boolean isConnect(Context context){
	    	ConnectivityManager manager = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
			//��ȡ״̬
			State wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
			State mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState();
			State hipri = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE_HIPRI).getState();
			//�ж�wifi�����ӵ�����
			if(wifi == State.CONNECTED||wifi==State.CONNECTING
					||mobile == State.CONNECTED||hipri == State.CONNECTED){
				return true;
			}else{
				return false;
				
			}
	    }
}
