package com.dapeng.util;



import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class BiaoLineView extends View{
    float startx,starty,stopx,stopy;
	public BiaoLineView(Context context,float startx,float starty,float stopx,float stopy) {
		super(context);
		// TODO Auto-generated constructor stub
		this.startx = startx;
		this.starty = starty;
		this.stopx = stopx;
		this.stopy = stopy;
	}
    public void onDraw(Canvas canvas){
    	super.onDraw(canvas);
    	Paint paint = new Paint();
    	paint.setAntiAlias(true);
    	paint.setStrokeWidth(5);
    	paint.setColor(Color.RED);
    	canvas.drawLine(startx, starty, stopx, stopy, paint);
    }

}
