package com.dapeng.activity;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ChuangLianActivity  extends Activity implements OnClickListener{
    Button openBt,pauseBt,closeBt,allopenBt;
    int addr1 = 0,addr2 = 0;
    int jiedian = 0xA6;
    int num = 0;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_chuanglian);
    	openBt = (Button) findViewById(id.chuanglian_openbt);
    	pauseBt = (Button) findViewById(id.chuanglian_pausebt);
    	closeBt = (Button) findViewById(id.chuanglian_closebt);
    	allopenBt = (Button) findViewById(id.chuanglian_allopenbt);
    	
    	openBt.setOnClickListener(this);
    	pauseBt.setOnClickListener(this);
    	closeBt.setOnClickListener(this);
    	allopenBt.setOnClickListener(this);
    }
	Handler myHandler = new Handler(){
	  		public void handleMessage(android.os.Message msg) {
	  			switch (msg.what) {
	  			case Util.ALLDATA:
	  				break;
	  			case Util.FDDATA:
	  				String msg1[]= msg.obj.toString().split(" ");
	  			    parseData_chuanglian(msg1);
	  				break;
	  			}
	  		}
	 };
	 private void parseData_chuanglian(String dataStr[]){
		 byte data[] = HexDump.hexStringToByteArray(dataStr[17]+dataStr[18]);
	  	 addr1 = data[0];
	  	 addr2 = data[1];
	 }
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.chuanglian_openbt://��
			int datas[] = {addr1,addr2,jiedian,0x4E,0xAA,0xAA,0xAA};
			sendMsgToService(datas,Util.DSONE5OPEN);
			break;
		case R.id.chuanglian_closebt:
			int datas1[] = {addr1,addr2,jiedian,0x46,0xAA,0xAA,0xAA};
			sendMsgToService(datas1,Util.DSONE5OPEN);
			break;
		case R.id.chuanglian_pausebt:
			int datas2[] = {addr1,addr2,jiedian,0x46,0xAA,0xAA,0xAA};
			sendMsgToService(datas2,Util.DSONE5OPEN);
			break;
		case R.id.chuanglian_allopenbt:
			if(num==0){
				int datas3[] = {addr1,addr2,jiedian,0x4E,0xAA,0xAA,0xAA};
				sendMsgToService(datas3,Util.DSONE5OPEN);
				num=1;
				allopenBt.setText("�رմ���");
			}else if(num==1){
				int datas3[] = {addr1,addr2,jiedian,0x46,0xAA,0xAA,0xAA};
				sendMsgToService(datas3,Util.DSONE5OPEN);
				num=0;
				allopenBt.setText("�򿪴���");
			}
			
			break;
		}
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Util.uiHandler = myHandler;
    	Util.whichBlock = "A6";
	}
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
    	super.onDestroy();
    }
    private void sendMsgToService(int datas[],int what){
	  if(MainZigBeeService.myHandler!=null){
		 if(Util.addr1!=0||Util.addr2!=0){
			Message msg = Message.obtain();
			msg.what = what;
			msg.obj = datas;
			MainZigBeeService.myHandler.sendMessage(msg);
		 }else{
			showMsg("�޷���ȡ������ư�����ڵ�ַ���������ڸð�δ����");
		 }			
	  }else{
		 showMsg("����δ��������������û���豸����");
	  }
	}
   public void showMsg(String text){
			Toast.makeText(this, text,200).show();
   } 
}
