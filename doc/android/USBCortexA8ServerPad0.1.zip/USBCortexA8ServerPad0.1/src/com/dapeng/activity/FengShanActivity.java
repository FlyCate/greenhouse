package com.dapeng.activity;


import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;


import com.dapeng.R;
import com.dapeng.R.id;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;

public class FengShanActivity extends Activity implements OnClickListener{
    ImageView fengshanImg1,fengshanImg2,fengshanImg3,fengshanImg4,fengshanImg5,fengshanImg6,fengshanImg7,fengshanImg8,ledImg1,jsqImg;
    int dangWei = 5;
    Animation myAnimation;//���� 
    Button fengshan_openBt1,fengshan_closeBt1,fengshan_openBt2,fengshan_closeBt2,fengshan_openBt3,fengshan_closeBt3,fengshan_openBt4,
    fengshan_closeBt4,led_openBt1,led_closeBt1,jsq_openBt2,jsq_closeBt2;
    int jiedian1 = 0x05,jiedian2 = 0x06;
    Handler myHandler = new Handler(){
  		public void handleMessage(android.os.Message msg) {
  			switch (msg.what) {
  			case Util.ALLDATA:
  				break;
  			case Util.FDDATA:
  				String msg1[]= msg.obj.toString().split(" ");
  				if(msg1[4].equals("A6")){
  					parseData_fengshan(msg1);
  				}else if(msg1[4].equals("A7")){
  					parseData_led(msg1);
  				}
  			    
  				break;
  			}
  		}
  	};
  //����
  	private void parseData_fengshan(String dataStr[]){
  		
  		if(dataStr[5].equals("4E")){
  			roundSpeed(dangWei,fengshanImg1);
  			roundSpeed(dangWei,fengshanImg2);
  		}else if(dataStr[5].equals("46")){
  			fengshanImg1.clearAnimation();
  			fengshanImg2.clearAnimation();
  		}
  		
       if(dataStr[6].equals("4E")){
    	   roundSpeed(dangWei,fengshanImg3);
 		   roundSpeed(dangWei,fengshanImg4);
  		}else if(dataStr[6].equals("46")){
  			fengshanImg3.clearAnimation();
  			fengshanImg4.clearAnimation();
  		}
       if(dataStr[7].equals("4E")){
 			roundSpeed(dangWei,fengshanImg5);
 			roundSpeed(dangWei,fengshanImg6);
 		}else if(dataStr[7].equals("46")){
 			fengshanImg5.clearAnimation();
 			fengshanImg6.clearAnimation();
 		}
 		
      if(dataStr[8].equals("4E")){
   	       roundSpeed(dangWei,fengshanImg7);
		   roundSpeed(dangWei,fengshanImg8);
 		}else if(dataStr[8].equals("46")){
 			fengshanImg7.clearAnimation();
 			fengshanImg8.clearAnimation();
 		}
		
  	}
    //��
  	private void parseData_led(String dataStr[]){

  		if(dataStr[5].equals("4E")){
  			ledImg1.setImageResource(R.drawable.light_on);
  		}else if(dataStr[5].equals("46")){
  			ledImg1.setImageResource(R.drawable.light_off);
  		}
  		
       if(dataStr[6].equals("4E")){
    	   jsqImg.setImageResource(R.drawable.jspopen);
  		}else if(dataStr[6].equals("46")){
  			jsqImg.setImageResource(R.drawable.jsqclose);
  		}
  		
		
  	}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_fengshan);
    	
    	 fengshan_openBt1 = (Button) findViewById(id.fengshan_openbt1);
    	 fengshan_closeBt1 = (Button) findViewById(id.fengshan_closebt1);
    	 fengshan_openBt2 = (Button) findViewById(id.fengshan_openbt2);
    	 fengshan_closeBt2 = (Button) findViewById(id.fengshan_closebt2);
    	 fengshan_openBt3 = (Button) findViewById(id.fengshan_openbt3);
    	 fengshan_closeBt3 = (Button) findViewById(id.fengshan_closebt3);
    	 fengshan_openBt4 = (Button) findViewById(id.fengshan_openbt4);
    	 fengshan_closeBt4 = (Button) findViewById(id.fengshan_closebt4);
    	 led_openBt1 = (Button) findViewById(id.led_openbt1);
    	 led_closeBt1 = (Button) findViewById(id.led_closebt1);
    	 jsq_openBt2 = (Button) findViewById(id.jsq_openbt2);
    	 jsq_closeBt2 = (Button) findViewById(id.jsq_closebt2);
    	 fengshan_openBt1.setOnClickListener(this);
    	 fengshan_closeBt1.setOnClickListener(this);
    	 fengshan_openBt2.setOnClickListener(this);
    	 fengshan_closeBt2.setOnClickListener(this);
    	 fengshan_openBt3.setOnClickListener(this);
    	 fengshan_closeBt3.setOnClickListener(this);
    	 fengshan_openBt4.setOnClickListener(this);
    	 fengshan_closeBt4.setOnClickListener(this);
    	 led_openBt1.setOnClickListener(this);
    	 led_closeBt1.setOnClickListener(this);
    	 jsq_openBt2.setOnClickListener(this);
    	 jsq_closeBt2.setOnClickListener(this);

    	 fengshanImg1 = (ImageView) findViewById(id.fengshan_img1);
    	 fengshanImg2 = (ImageView) findViewById(id.fengshan_img2);
    	 fengshanImg3 = (ImageView) findViewById(id.fengshan_img3);
    	 fengshanImg4= (ImageView) findViewById(id.fengshan_img4);
    	 fengshanImg5 = (ImageView) findViewById(id.fengshan_img5);
    	 fengshanImg6 = (ImageView) findViewById(id.fengshan_img6);
    	 fengshanImg7 = (ImageView) findViewById(id.fengshan_img7);
    	 fengshanImg8 = (ImageView) findViewById(id.fengshan_img8);
    	 ledImg1 = (ImageView) findViewById(id.led_img1);
    	 jsqImg = (ImageView) findViewById(id.jsq_img);
    	
    	
    }
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		MainZigBeeService.stopTimer();
		switch(v.getId()){
		case R.id.fengshan_openbt1:
			//ketingImg.setImageResource(R.drawable.light_on);
			int datas[] = {jiedian1,0x0A,0x4B,0x4E,0xAA,0xAA,0xAA};
			sendMsgToService(datas,Util.DSONE5OPEN);
			break;
		case R.id.fengshan_closebt1:
			//ketingImg.setImageResource(R.drawable.light_off);
			int datas1[] = {jiedian1,0x0A,0x4B,0x46,0xAA,0xAA,0xAA};
			sendMsgToService(datas1,Util.DSONE5OPEN);
			break;
		case R.id.fengshan_openbt2:
			//zhuwoImg.setImageResource(R.drawable.light_on);
			int datas2[] = {jiedian1,0x0A,0x4B,0xAA,0x4E,0xAA,0xAA};
			sendMsgToService(datas2,Util.DSONE5OPEN);
			break;
		case R.id.fengshan_closebt2:
			//zhuwoImg.setImageResource(R.drawable.light_off);
			int datas3[] = {jiedian1,0x0A,0x4B,0xAA,0x46,0xAA,0xAA};
			sendMsgToService(datas3,Util.DSONE5OPEN);
			break;
		case R.id.fengshan_openbt3:
			//ciwoImg.setImageResource(R.drawable.light_on);
			int datas4[] = {jiedian1,0x0A,0x4B,0xAA,0xAA,0x4E,0xAA};
			sendMsgToService(datas4,Util.DSONE5OPEN);
			break;
		case R.id.fengshan_closebt3:
			//ciwoImg.setImageResource(R.drawable.light_off);
			int datas5[] = {jiedian1,0x0A,0x4B,0xAA,0xAA,0x46,0xAA};
			sendMsgToService(datas5,Util.DSONE5OPEN);
			break;
		case R.id.fengshan_openbt4:
			//ciwoImg.setImageResource(R.drawable.light_on);
			int datas6[] = {jiedian1,0x0A,0x4B,0xAA,0xAA,0xAA,0x4E};
			sendMsgToService(datas6,Util.DSONE5OPEN);
			break;
		case R.id.fengshan_closebt4:
			//ciwoImg.setImageResource(R.drawable.light_off);
			int datas7[] = {jiedian1,0x0A,0x4B,0xAA,0xAA,0xAA,0x46};
			sendMsgToService(datas7,Util.DSONE5OPEN);
			break;
		case R.id.led_openbt1:
			//ciwoImg.setImageResource(R.drawable.light_off);
			int datas8[] = {jiedian2,0x0A,0x4B,0x4E,0xAA,0xAA,0xAA};
			sendMsgToService(datas8,Util.DSONE5OPEN);
			break;
		case R.id.led_closebt1:
			//ciwoImg.setImageResource(R.drawable.light_off);
			int datas9[] = {jiedian2,0x0A,0x4B,0x46,0xAA,0xAA,0xAA};
			sendMsgToService(datas9,Util.DSONE5OPEN);
			break;
		case R.id.jsq_openbt2:
			//ciwoImg.setImageResource(R.drawable.light_off);
			int datas10[] = {jiedian2,0x0A,0x4B,0xAA,0x4E,0xAA,0xAA};
			sendMsgToService(datas10,Util.DSONE5OPEN);
			break;
		case R.id.jsq_closebt2:
			//ciwoImg.setImageResource(R.drawable.light_off);
			int datas11[] = {jiedian2,0x0A,0x4B,0xAA,0x46,0xAA,0xAA};
			sendMsgToService(datas11,Util.DSONE5OPEN);
			break;
	
		}
	}
	//
	//
	 @Override
    protected void onResume() {
		    	//����Ϊ��activity��handler
	  Util.uiHandler = myHandler;
	  Util.whichBlock = "showdata";
	  super.onResume();
	}
	private void sendMsgToService(int datas[],int what){
	  if(MainZigBeeService.myHandler!=null){
			Message msg = Message.obtain();
			msg.what = what;
			msg.obj = datas;
			MainZigBeeService.myHandler.sendMessage(msg);
				
	  }else{
		showMsg("����δ��������������û���豸����");
	  }
	}
    public void showMsg(String text){
	  Toast.makeText(this, text,200).show();
	}
    private void roundSpeed(int speed,ImageView iv){			
		myAnimation=new RotateAnimation(0.0f, +359.9f, Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF, 0.5f);
		myAnimation.setRepeatCount(-1);
		myAnimation.setDuration(3000/speed);
		LinearInterpolator lir1 = new LinearInterpolator();    
		myAnimation.setInterpolator(lir1);				
	    iv.startAnimation(myAnimation);
   }

}
