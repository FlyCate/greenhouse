package com.dapeng.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;

@SuppressLint("HandlerLeak")
public class DesignOneActivity extends Activity implements OnClickListener{
	Animation myAnimation_RotateZheng;//�������� 
	Animation myAnimation_RotateFan;//�������� 
	Button back,oneOpen,twoBt1,twoBt2,twoBt3,twoOpen1,twoOpen2,twoFan,twoZheng,threeOpen,threeAdd,threeMinu,fourOpen,fiveOpen,fiveAdd,fiveMinu,lookdata;
	EditText threeEt,fourEt,fiveEt;
	TextView addressTv,netNumTv,singleTv,fourTv;
	ImageView oneShowIv,oneIv1,twoIv1,twoIv2,twoIv3,twoIv4;
	boolean oneIsOpen = false,twoBt1IsOpen=false,twoBt2IsOpen=false,twoBt3IsOpen=false,twoIsOpen1=false,twoIsOpen2=false,fourIsOpen = false;//threeIsOpen=false,fiveIsOpen=false;
	Handler myHandler = new Handler(){//���պ�̨��������
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.FDDATA:
				parseData((String)msg.obj);
				break;
			case Util.NETADRR:
				addressTv.setText("���ڵ�ַ��"+msg.obj);
				break;
			case Util.NETNUM:
				netNumTv.setText("����ţ�"+msg.obj);
				break;
			case Util.SINGLENUM:
				singleTv.setText("�ŵ��ţ�"+msg.obj);
				break;
			}
		}
	};
	//�����ش�����
	private void parseData(String dataStr){
		 try {
			 String msg[]= dataStr.split(" ");
			 if(oneIsOpen){
				 byte data[] = HexDump.hexStringToByteArray(msg[5]);
				 char c = (char)data[0];
				 if(c == 'F'){
					 oneShowIv.setImageResource(R.drawable.design_toggle_on);
				 }else if(c == 'N'){
					 oneShowIv.setImageResource(R.drawable.design_toggle_off);
				 }
			 }
			 if(fourIsOpen){//���ĸ�ģ�� Ƶ�ʲɼ�
				 byte data[] = HexDump.hexStringToByteArray(msg[6]+msg[7]);
				//�п��ܻ���ֳ���128������  �ڴ˻��Ϊ���� ��Ҫת��Ϊ0-256֮�������
				int numInt[] = new int[2];
				numInt[0] = data[0];
				numInt[1] = data[1];
				if(data[0]<0){
					numInt[0] = 256+data[0];
				}
				if(data[1]<0){
					numInt[1] = 256+data[1];
				}
				int num = numInt[0]*256+numInt[1];
				fourTv.setText(num+"");
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_designone);
		init();
		super.onCreate(savedInstanceState);
	}
	
	private void init(){
		myAnimation_RotateZheng=new RotateAnimation(0.0f, +359.9f, Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF, 0.5f);
		myAnimation_RotateZheng.setRepeatCount(-1);
		myAnimation_RotateZheng.setDuration(3000);
		LinearInterpolator lir1 = new LinearInterpolator();    
		myAnimation_RotateZheng.setInterpolator(lir1); 
		
		myAnimation_RotateFan=new RotateAnimation(0.0f, -359.9f, Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF, 0.5f);
		myAnimation_RotateFan.setRepeatCount(-1);
		myAnimation_RotateFan.setDuration(3000);
		LinearInterpolator lir2 = new LinearInterpolator();    
		myAnimation_RotateFan.setInterpolator(lir2); 
		
		threeEt = (EditText)this.findViewById(R.id.ds_one_three_et1);
		addressTv = (TextView)this.findViewById(R.id.design_one_addr_tv);
		netNumTv = (TextView)this.findViewById(R.id.design_one_netNum_tv);
		singleTv = (TextView)this.findViewById(R.id.design_one_singelNum_tv);
		fourTv = (TextView)this.findViewById(R.id.ds_one_four_tv1);
		fourTv = (TextView)this.findViewById(R.id.ds_one_four_tv1);
		fourTv = (TextView)this.findViewById(R.id.ds_one_four_tv1);
		fiveEt = (EditText)this.findViewById(R.id.ds_one_five_et1);
		
		back = (Button)this.findViewById(R.id.design_one_back);
		back.setOnClickListener(this);
		
		oneShowIv = (ImageView)this.findViewById(R.id.ds_one_one_iv2);
		
		oneIv1 = (ImageView)this.findViewById(R.id.ds_one_one_iv1);
		twoIv1 = (ImageView)this.findViewById(R.id.ds_one_two_iv1);
		twoIv2 = (ImageView)this.findViewById(R.id.ds_one_two_iv2);
		twoIv3 = (ImageView)this.findViewById(R.id.ds_one_two_iv3);
		twoIv4 = (ImageView)this.findViewById(R.id.ds_one_two_iv4);
		
		oneOpen = (Button)this.findViewById(R.id.ds_one_one_bt1);
		twoBt1 = (Button)this.findViewById(R.id.ds_one_two_bt1);
		twoBt2 = (Button)this.findViewById(R.id.ds_one_two_bt2);
		twoBt3 = (Button)this.findViewById(R.id.ds_one_two_bt3);
		
		twoOpen1 = (Button)this.findViewById(R.id.ds_one_two_bt6);
		twoOpen2 = (Button)this.findViewById(R.id.ds_one_two_bt7);
		twoFan = (Button)this.findViewById(R.id.ds_one_two_bt4);
		twoZheng = (Button)this.findViewById(R.id.ds_one_two_bt5);
		threeOpen = (Button)this.findViewById(R.id.ds_one_three_btopen);
		threeAdd = (Button)this.findViewById(R.id.ds_one_three_btadd);
		threeMinu = (Button)this.findViewById(R.id.ds_one_three_btminu);
		fourOpen = (Button)this.findViewById(R.id.ds_one_four_btopen);
		fiveOpen = (Button)this.findViewById(R.id.ds_one_five_btopen);
		fiveAdd = (Button)this.findViewById(R.id.ds_one_five_btadd);
		fiveMinu = (Button)this.findViewById(R.id.ds_one_five_btminu);
		lookdata = (Button) this.findViewById(id.design_one_lookdata_btn);
		oneOpen.setOnClickListener(this);
		twoOpen1.setOnClickListener(this);
		twoBt1.setOnClickListener(this);
		twoBt2.setOnClickListener(this);
		twoBt3.setOnClickListener(this);
		twoOpen2.setOnClickListener(this);
		twoFan.setOnClickListener(this);
		twoZheng.setOnClickListener(this);
		threeOpen.setOnClickListener(this);
		threeAdd.setOnClickListener(this);
		threeMinu.setOnClickListener(this);
		fourOpen.setOnClickListener(this);
		fiveOpen.setOnClickListener(this);
		fiveAdd.setOnClickListener(this);
		fiveMinu.setOnClickListener(this);
		lookdata.setOnClickListener(this);
	}
	
	@Override
    protected void onResume() {
    	//����Ϊ��activity��handler
		Util.uiHandler = myHandler;
        Util.whichBlock = "A8";
    	super.onResume();
    }
	
	@Override
	protected void onPause() {
		super.onPause();
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.design_one_back:
			this.finish();
			break;
		case R.id.ds_one_one_bt1://��һģ�� ������ť
			if(oneIsOpen){//�����ǰ�Ǵ򿪵�  ��ô�ر�  ���Ѱ�ť��������Ϊ��
				oneOpen.setText("��");
				oneIv1.setImageResource(R.drawable.design_icon_off);
				oneIsOpen = false;
			}else{
				oneOpen.setText("�ر�");
				oneIv1.setImageResource(R.drawable.design_icon_on);
				oneIsOpen = true;
			}
			break;
		case R.id.ds_one_two_bt1://�ڶ�ģ�鰴ť1
			twoBt1IsOpen = openCloseBlockTwo(twoBt1IsOpen,0x00,0x01,Util.DSONE2BT1,1);
			break;
		case R.id.ds_one_two_bt2://�ڶ�ģ�鰴ť2
			twoBt2IsOpen = openCloseBlockTwo(twoBt2IsOpen,0x01,0x02,Util.DSONE2BT2,2);
			break;
		case R.id.ds_one_two_bt3://�ڶ�ģ�鰴ť3
			twoBt3IsOpen = openCloseBlockTwo(twoBt3IsOpen,0x02,0x03,Util.DSONE2BT3,3);
			break;
		case R.id.ds_one_two_bt6://�ڶ�ģ��򿪰�ť1
			twoIsOpen1 = openCloseBlockTwo(twoIsOpen1,0x00,0x01,Util.DSONE2OPEN1,4);
			break;
		case R.id.ds_one_two_bt7://�ڶ�ģ��򿪰�ť2
			if(twoIsOpen2){
				twoOpen2.setText("��");
				twoIsOpen2 = false;
				int datas[] = {Util.addr1,Util.addr2,0x40,0x01,('S' & 0xff),0xAA,0xAA};
				sendMsgToService(datas,Util.DSONE2OPEN2);
				twoIv4.clearAnimation();
			}else{
				twoOpen2.setText("�ر�");
				twoIsOpen2 = true;
				int datas[] = {Util.addr1,Util.addr2,0x40,0x01,0x11,0xAA,0xAA};
				sendMsgToService(datas,Util.DSONE2OPEN2);
				twoIv4.startAnimation(myAnimation_RotateZheng);
			}
			break;
		case R.id.ds_one_two_bt4://�ڶ���ģ�� ��
			if(twoIsOpen2){//�������֮��
				int datasf[] = {Util.addr1,Util.addr2,0x40,0x01,0x22,0xAA,0xAA};
				sendMsgToService(datasf,Util.DSONE2OPEN2);
				twoIv4.startAnimation(myAnimation_RotateFan);
			}
			break;
		case R.id.ds_one_two_bt5://�ڶ���ģ�� ��
			if(twoIsOpen2){//�������֮��
				int datasz[] = {Util.addr1,Util.addr2,0x40,0x01,0x11,0xAA,0xAA};
				sendMsgToService(datasz,Util.DSONE2OPEN2);
				twoIv4.startAnimation(myAnimation_RotateZheng);
			}
			break;
		case R.id.ds_one_three_btopen:
//			if(threeIsOpen){
//				threeOpen.setText("����");
//				threeIsOpen= false;
				String zkStr = threeEt.getText().toString()+"";
				if(zkStr.length()>0){
					int zk = Integer.parseInt(zkStr);
					int datas[] = {Util.addr1,Util.addr2,0x40,0x03,(zk & 0xff),0xAA,0xAA};
					sendMsgToService(datas,Util.DSONE3OPEN);
				}
//			}else{
//				threeOpen.setText("�ر�");
//				threeIsOpen= true;
//			}
			break;
		case R.id.ds_one_three_btadd:
			addOrMinuEt(1,threeEt,100,0,1);
			break;
		case R.id.ds_one_three_btminu:
			addOrMinuEt(0,threeEt,100,0,1);
			break;
		case R.id.ds_one_four_btopen:
			if(fourIsOpen){
				fourOpen.setText("��");
				fourIsOpen = false;
			}else{
				fourOpen.setText("�ر�");
				fourIsOpen = true;
			}
			break;
		case R.id.ds_one_five_btopen:
//			if(fiveIsOpen){
//				fiveOpen.setText("��");
//				fiveIsOpen = false;
//			}else{
//				fiveOpen.setText("�ر�");
//				fiveIsOpen = true;
				block5SendData();
//			}
			break;
		case R.id.ds_one_five_btadd:
			addOrMinuEt(1,fiveEt,10000,500,100);
			//block5SendData();
			break;
		case R.id.ds_one_five_btminu:
			addOrMinuEt(0,fiveEt,10000,500,100);
			//block5SendData();
			break;
		case R.id.design_one_lookdata_btn:
		     Intent intent =new Intent(DesignOneActivity.this,DataShowActivity.class);
			 startActivity(intent);	
		default:
			break;
		}
	}
	
	
	private void block5SendData(){
		String zkStr = fiveEt.getText().toString()+"";
		if(zkStr.length()>2){//&&fiveIsOpen
			int zk = Integer.parseInt(zkStr);
//			byte numBytes[]=  HexDump.toByteArray(zk);
			//�п��ܻ���ֳ���128������  �ڴ˻��Ϊ���� ��Ҫת��Ϊ0-256֮�������
//			int numInt[] = new int[2];
//			numInt[0] = numBytes[numBytes.length-2];
//			numInt[1] = numBytes[numBytes.length-1];
//			if(numBytes[numBytes.length-2]<0){
//				numInt[0] = 256+numBytes[numBytes.length-2];
//			}
//			if(numBytes[numBytes.length-1]<0){
//				numInt[1] = 256+numBytes[numBytes.length-1];
//			}
			int gao = zk/256;
			int di = zk%256;
			//System.out.println((numInt[0] & 0xff)+"  "+numInt[1]);
			int datas[] = {Util.addr1,Util.addr2,0x40,0x04,gao,di,0xAA};
			sendMsgToService(datas,Util.DSONE5OPEN);
		}
	}
	//ģ��2��3����ť���ƴ���
	//num 4Ϊģ��2�еĵ�һ�����ذ�ť  1 2 3�ֱ�Ϊ��ť1 2 3
	private boolean openCloseBlockTwo(boolean flag,int msgclose,int msgopen,int what,int num){
		if(twoIsOpen1||num == 4){
			if(flag){//��
//				int datas[] = {Util.addr1,Util.addr2,0x40,0x02,msgclose,0xAA,0xAA};
//				sendMsgToService(datas,what);
				switch (num) {
				case 1:
					twoIv1.setImageResource(R.drawable.design_icon_on);
					twoIv2.setImageResource(R.drawable.design_icon_off);
					twoIv3.setImageResource(R.drawable.design_icon_off);
					int datas1[] = {Util.addr1,Util.addr2,0x40,0x02,msgopen,0xAA,0xAA};
					sendMsgToService(datas1,what);
					break;
				case 2:
					twoIv1.setImageResource(R.drawable.design_icon_on);
					twoIv2.setImageResource(R.drawable.design_icon_on);
					twoIv3.setImageResource(R.drawable.design_icon_off);
					int datas2[] = {Util.addr1,Util.addr2,0x40,0x02,msgopen,0xAA,0xAA};
					sendMsgToService(datas2,what);
					break;
				case 3:
					twoIv1.setImageResource(R.drawable.design_icon_on);
					twoIv2.setImageResource(R.drawable.design_icon_on);
					twoIv3.setImageResource(R.drawable.design_icon_on);
					int datas3[] = {Util.addr1,Util.addr2,0x40,0x02,msgopen,0xAA,0xAA};
					sendMsgToService(datas3,what);
					break;
				case 4:
					twoIv1.setImageResource(R.drawable.design_icon_off);
					twoIv2.setImageResource(R.drawable.design_icon_off);
					twoIv3.setImageResource(R.drawable.design_icon_off);
					int datas4[] = {Util.addr1,Util.addr2,0x40,0x02,msgclose,0xAA,0xAA};
					sendMsgToService(datas4,what);
					twoOpen1.setText("��");
					break;
				}
				return false;
			}else{
				int datas[] = {Util.addr1,Util.addr2,0x40,0x02,msgopen,0xAA,0xAA};
				sendMsgToService(datas,what);
				switch (num) {
				case 1:
					twoIv1.setImageResource(R.drawable.design_icon_on);
					twoIv2.setImageResource(R.drawable.design_icon_off);
					twoIv3.setImageResource(R.drawable.design_icon_off);
					break;
				case 2:
					twoIv1.setImageResource(R.drawable.design_icon_on);
					twoIv2.setImageResource(R.drawable.design_icon_on);
					twoIv3.setImageResource(R.drawable.design_icon_off);
					break;
				case 3:
					twoIv1.setImageResource(R.drawable.design_icon_on);
					twoIv2.setImageResource(R.drawable.design_icon_on);
					twoIv3.setImageResource(R.drawable.design_icon_on);
					break;
				case 4:
					twoIv1.setImageResource(R.drawable.design_icon_on);
					twoIv2.setImageResource(R.drawable.design_icon_off);
					twoIv3.setImageResource(R.drawable.design_icon_off);
					twoOpen1.setText("�ر�");
					break;
				}
				return true;
			}
		}
		return false;
	}
	
	private void addOrMinuEt(int addOrMinu,EditText et,int max,int min,int addOrMinnum){//0Ϊ-  1Ϊ+  
		String numStr = et.getText().toString().trim()+"";
		if(numStr.length()>0){
			int num = Integer.parseInt(numStr);
			if(addOrMinu==0){
				if(num>min){
					num = num-addOrMinnum;
				}
			}else{
				if(num<max){
					num = num+addOrMinnum;
				}
			}
			et.setText(num+"");
		}
	}
	
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
	private void sendMsgToService(int datas[],int what){
		if(MainZigBeeService.myHandler!=null){
			if(Util.addr1!=0||Util.addr2!=0){
				Message msg = Message.obtain();
				msg.what = what;
				msg.obj = datas;
				MainZigBeeService.myHandler.sendMessage(msg);
			}else{
				showMsg("�޷���ȡ������ư�����ڵ�ַ���������ڸð�δ����");
			}
		}else{
			showMsg("����δ��������������û���豸����");
		}
	}
	
	public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
}
