package com.dapeng.activity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;





import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class HistoricalDataActivity extends Activity implements OnClickListener{
	LineGraphicView tu;
	ArrayList<Double> yList;
	ArrayList<String> xRawDatas;
	Button chaxunBt;
	LinearLayout graphic;
	TextView tableYName;
	int min = -20,max = 100,jiange = 20;
	ArrayAdapter<String> saRate22;
	ArrayAdapter<String> saRate44;
	ListView hisListView;//�����б�
	private String jiedian_add = "09";
	Spinner startYear,startMonth,startDay,stopYear,stopMonth,stopDay,cgq;
	String month[] = {"1","2","3","4","5","6","7","8","9","10","11","12"};
	String day1[] = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28"};
	String day2[] = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29"};
	String day3[] = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"};
	String day4[] = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
	String chuanganqi[] = {"�����¶�","����ʪ��","������̼","���ն�","�����¶�","����ʪ��","���ٷ���"};
	String year[] = new String[2];
	private String startTime = null;
	private String stopTime = null;
	ArrayList<Double> yList1;
	ArrayList<String> xRawDatas1;
	Handler hisHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 0:
				
				parseData((String)msg.obj);
				break;
			case Util.FDDATA:
				System.out.println((String)msg.obj);
				break;
			}
		}
	};
	private void parseData(String str){
		String strs[] = str.split(",");
		String datas[] = null;
		String Times[] = null;
		String value = null;
		String time = null;
		yList.clear();
		xRawDatas.clear();
		for(int i=0;i<strs.length;i++){
			System.out.println("��ʷ���ݲ�ѯ="+strs[i]);
			if(strs[i].startsWith("\"data\"")){
				datas = strs[i].split(":");
				Data(datas[1].split(" "));
				
			}else if(strs[i].startsWith("\"happenTime\"")){
				Times = strs[i].split(":");
				time = Times[1].substring(2)+":"+Times[2];
				xRawDatas.add(time);
			}
		}
		if(datas!=null && Times!=null){
			yList1.clear();
			xRawDatas1.clear();
			if(yList.size()>=5){
				for(int i=0;i<5;i++){
					yList1.add(yList.get(i));
					xRawDatas1.add(xRawDatas.get(i));
					System.out.println("yList.get(i)="+yList.get(i));
					System.out.println("xRawDatas.get(i)="+xRawDatas.get(i));
				}
			}
			graphic.addView(tu);
			tu.setData(yList1, xRawDatas1, max, jiange,min);
			for(int i=0;i<yList.size();i++){
				 getDataShowList(yList.get(i)+"",xRawDatas.get(i));
			}
			
		}
	}
	private void Data(String strs[]){
		   byte dataByte[] = HexDump.hexStringToByteArray(strs[6]+strs[7]+strs[8]+strs[9]);
		   int numInt[] = new int[4];
		   numInt[0] = dataByte[0];
		   numInt[1] = dataByte[1];
		   numInt[2] = dataByte[2];
		   numInt[3] = dataByte[3];
		   if(dataByte[0]<0){
				numInt[0] = 256+dataByte[0];
			}
			if(dataByte[1]<0){
				numInt[1] = 256+dataByte[1];
			}
			if(dataByte[2]<0){
				numInt[2] = 256+dataByte[2];
			}
			if(dataByte[3]<0){
				numInt[3] = 256+dataByte[3];
			}
		   switch(cgq.getSelectedItemPosition()){
		   case 0://�����¶�
			   yList.add(Double.parseDouble (numInt[0]+"."+numInt[1]));
			   break;
		   case 1://����ʪ��
			   yList.add(Double.parseDouble (numInt[2]+"."+numInt[3]));
			   break;
		   case 2://������̼
			   yList.add((double) (numInt[0]*256+numInt[1]));
			   break;
		   case 3://���ն�
			   yList.add((double) (numInt[0]*256+numInt[1]));
			   break;
		   case 4://�����¶�
			   yList.add(Double.parseDouble (numInt[0]+"."+numInt[1]));
		   case 5://����ʪ��
			   yList.add(Double.parseDouble (numInt[0]+"."+numInt[1])-3);
		   case 6://���ٷ���
			   yList.add((double) (numInt[0]*256+numInt[1])/100);
			   break;
		   }
		}
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_historicaldata);
		
          
		yList = new ArrayList<Double>();
		yList.add(0.00);
		yList.add(20.00);
		yList.add(40.0);
		yList.add(60.0);
		yList.add(80.05);
		yList.add(-6.00);
		yList.add(-10.00);
		yList.add(20.00);
		yList.add(14.0);
		yList.add(10.0);

		xRawDatas = new ArrayList<String>();
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
		xRawDatas.add("05-12-25 ");
//		tu.setData(yList, xRawDatas, 1000, 20,-20);
//		tu =   (LineGraphicView) findViewById(R.id.line_graphic);
//		tu.setData(yList, xRawDatas, 1000, 20,-20);
		
		tu = new LineGraphicView(this);
		graphic = (LinearLayout) findViewById(R.id.line_graphic);
		graphic.addView(tu);
		tu.setData(yList, xRawDatas, 1000, 20,0);
		 Calendar c =  Calendar.getInstance();
		 year[0] = String.valueOf(c.get(Calendar.YEAR));
		 year[1] = String.valueOf(c.get(Calendar.YEAR)-1);
		 
		 startYear = (Spinner) findViewById(id.history_start_year);
		 startYear.setTag("startYear");
		 startMonth= (Spinner) findViewById(id.history_start_month);
		
		 startDay = (Spinner) findViewById(id.history_start_day);
		 stopYear = (Spinner) findViewById(id.history_stop_year);
		 stopMonth = (Spinner) findViewById(id.history_stop_month);
		 stopDay = (Spinner) findViewById(id.history_stop_day);
		 cgq = (Spinner) findViewById(id.history_cgq);
		 
		 chaxunBt = (Button) findViewById(id.history_chaxun);
		 chaxunBt.setOnClickListener(this);
		 
		 tableYName = (TextView) findViewById(id.history_table_yname);
		 hisListView = (ListView)this.findViewById(R.id.history_listView1);
		 
	      ArrayAdapter<String> saRate = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, year);  
		  saRate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  startYear.setAdapter(saRate);
		  
		  ArrayAdapter<String> saRate1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, month);  
		  saRate1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  startMonth.setAdapter(saRate1);
		  
		  ArrayAdapter<String> saRate2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, day1);  
		  saRate2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  startDay.setAdapter(saRate2);
		  
		  ArrayAdapter<String> saRate3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, year);  
		  saRate3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  stopYear.setAdapter(saRate3);
			  
		  ArrayAdapter<String> saRate4 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, month);  
		  saRate4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  stopMonth.setAdapter(saRate4);
			  
		  ArrayAdapter<String> saRate5 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, day1);  
		  saRate5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  stopDay.setAdapter(saRate5);
		  
		  ArrayAdapter<String> saRate6 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, chuanganqi);  
		  saRate6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  cgq.setAdapter(saRate6);
		  
		  String from[] = {"left","right"};
		  int to[] = {R.id.item_textView1,R.id.item_textView2};
		  sAdapter = new SimpleAdapter(this, data, R.layout.datalist_item, from, to);
		  
		  startMonth.setOnItemSelectedListener(new startMonthItemSelectedListener());
		  stopMonth.setOnItemSelectedListener(new stopMonthItemSelectedListener());
		  startYear.setOnItemSelectedListener(new startYearOnItemSelectedListener());
		  stopYear.setOnItemSelectedListener(new stopYearOnItemSelectedListener());
    }	
	@Override
	public void onClick(View v) {
		graphic.removeAllViews();
		String danwei = "��";
		switch(v.getId()){
		case R.id.history_chaxun:
			switch(cgq.getSelectedItemPosition()){
			case 0://�����¶�
				danwei = "��";
				max = 100;
				min = -20;
				jiange = 10;
				jiedian_add = "09";
				break;
			case 1://����ʪ��
				max = 100;
				min = 0;
				jiange = 10;
				danwei = "%";
				jiedian_add = "09";
				break;
			case 2://������̼
				max = 1000;
				min = 0;
				jiange = 20;
				danwei = "pp/m";
				jiedian_add = "05";
				break;
			case 3://���ն�
				max = 1000;
				min = 0;
				jiange = 20;
				danwei = "lux";
				jiedian_add = "02";
				break;
			case 4://�����¶�
				max = 100;
				min = -20;
				jiange = 10;
				danwei = "��";
				jiedian_add = "B1";
				break;
			case 5://����ʪ��	
				max = 100;
				min = 0;
				jiange = 10;
				danwei = "%";
				jiedian_add = "B1";
				break;
			case 6://����	
				max = 100;
				min = 0;
				jiange = 10;
				danwei = "m/s";
				jiedian_add = "B4";
				break;
			}
			tableYName.setText(chuanganqi[cgq.getSelectedItemPosition()]+danwei);
			graphic.addView(tu);
			tu.setData(yList, xRawDatas, max, jiange,min);
			startTime = year[startYear.getSelectedItemPosition()]+"-"+month[startMonth.getSelectedItemPosition()]+"-"+day4[startDay.getSelectedItemPosition()];
			stopTime = year[stopYear.getSelectedItemPosition()]+"-"+month[stopMonth.getSelectedItemPosition()]+"-"+day4[stopDay.getSelectedItemPosition()];
		break;
		}
		selectData();
			    	
		
	} 
	Thread selectThread =null;
	private void selectData(){
		
		selectThread = new Thread(runselectThread);
		if(!selectThread.isAlive()){
			selectThread.start();
		}
	}

	 Runnable  runselectThread  = new Runnable(){
			public void run(){
		    	try {
		    		String uploadStr = "";
		    		String strUrl = Util.IP+"rdf?action=getManyHist&bn="+Util.boxNum+"&lx="+jiedian_add+"&origin=client&beginTime="+startTime+"&endTime="+stopTime;//�ϴ����ӱ��
//		    		String strUrl = Util.IP+"rdf?action=getManyHist&bn="+20+"&lx="+"09"+"&origin=client&beginTime="+"2016-1-8"+"&endTime="+"2016-1-8";//�ϴ����ӱ��
		    		System.out.println("strUrl="+strUrl);
		    		byte msg[] = uploadStr.getBytes("UTF-8");
		    		URL url = new URL(strUrl);
		    		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		    		//����ʽ
		    		conn.setRequestMethod("GET");
		    		if(conn.getResponseCode() == 200){
		    			byte b[] = inputStream2Bytes(conn.getInputStream());
						System.out.println("b.length   "+b.length);
						String downLoadStr = new String(b, "UTF-8");

			    			System.out.println("write out="+downLoadStr);
			    		//	parseData(downLoadStr);
			    			sendMsg(downLoadStr,0);
		    		}
		    		conn.disconnect();
		    	} catch (Exception e) {
		    		e.printStackTrace();
		    	}
			}
		};
		
	private void sendMsg(String msg1,int what){
		Message msg = Message.obtain();
		msg.what = what;
		msg.obj = msg1;
		if(hisHandler!=null){
			hisHandler.sendMessage(msg);
		}
	}	
	//�ͻ��˺ͷ�������Ҫ�õ��Ķ�ȡ������
	public byte[] inputStream2Bytes(InputStream inStream) {
	    	ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
	    	byte[] buff = new byte[1024];
	    	int rc = 0;
	    	try {
	    		while ((rc = inStream.read(buff, 0, 1024)) > 0) {
	    			swapStream.write(buff, 0, rc);
	    		}
	    		inStream.close();
	    		return swapStream.toByteArray();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		return null;
	    	}
	}
	class startMonthItemSelectedListener implements OnItemSelectedListener{

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			  switch(Integer.parseInt(month[arg2])){
				case 1:				
				case 3:
				case 5:
				case 7:
				case 8:
					 saRate22 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day4);  
					break;
				case 2:
					if(Integer.parseInt(year[startYear.getSelectedItemPosition()])/4==0){
						saRate22 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day2);  
					}else{
						saRate22 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day1);  
					}
					break;
				default :
					saRate22 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day3);  
						break;
				}
				saRate22.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
				startDay.setAdapter(saRate22);
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}}
	class stopMonthItemSelectedListener implements OnItemSelectedListener{

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			  switch(Integer.parseInt(month[arg2])){
				case 1:				
				case 3:
				case 5:
				case 7:
				case 8:
					 saRate44 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day4);  
					break;
				case 2:
					if(Integer.parseInt(year[stopYear.getSelectedItemPosition()])/4==0){
						saRate44 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day2);  
					}else{
						saRate44 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day1);  
					}
					break;
				default :
					saRate44 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day3);  
						break;
				}
				saRate44.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
				stopDay.setAdapter(saRate44);
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}}
	class startYearOnItemSelectedListener implements OnItemSelectedListener{

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1,
				int arg2, long arg3) {
			// TODO Auto-generated method stub
			if(Integer.parseInt(year[arg2])%4==0  && Integer.parseInt(year[arg2])==2){
				saRate22 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day2);
			}else{
				saRate22 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day1);
			}
			saRate22.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			startDay.setAdapter(saRate22);
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
	class stopYearOnItemSelectedListener implements OnItemSelectedListener{

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1,
				int arg2, long arg3) {
			// TODO Auto-generated method stub
			if(Integer.parseInt(year[arg2])%4==0  && Integer.parseInt(month[stopMonth.getSelectedItemPosition()])==2){
				saRate44 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day2);
			}else{
				saRate44 = new ArrayAdapter<String>(HistoricalDataActivity.this, android.R.layout.simple_spinner_item, day1);
			}
			saRate44.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			stopDay.setAdapter(saRate22);
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
	ArrayList<HashMap<String,String>> data = new ArrayList<HashMap<String,String>>();
	SimpleAdapter sAdapter;//�����б�������
	//���list������
	private void getDataShowList(String value,String time){
		
		System.out.println("zhaodu="+value);
		HashMap<String,String> hmdata = new HashMap<String, String>();
		hmdata.put("left", time);
		hmdata.put("right", value);
		data.add(hmdata);
		sAdapter.notifyDataSetChanged();
		hisListView.setSelection(data.size());
	}
}
