package com.dapeng.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;

//��¼���������
public class EnterActivity extends Activity implements OnClickListener{
	FrameLayout huanJingFl,yaoKongFl,anFangFl,wendu_bt;
	private TextView titleView;
	String boxNum;
	int addr1=0,addr2=0;
	Handler myHandler = new Handler(){//���պ�̨��������
		public void handleMessage(android.os.Message msg) {
			System.out.println("msg.what="+msg.what);
			switch (msg.what) {
			case Util.FDDATA:
//				acd.updateChart(35);
				parseData(msg.obj.toString());
				break;			
			}
		}
	};
	public void parseData(String msg){
		 String msg1[]= msg.split(" ");
		 byte bb[] = HexDump.hexStringToByteArray(msg1[17]+msg1[18]);
		 System.out.println("addr1+addr2"+addr1+addr2);
		 addr1 = bb[0];
		 addr2 = bb[1];
	}
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enter);		
		huanJingFl = (FrameLayout)this.findViewById(R.id.enter_huanjing_fl);
		yaoKongFl = (FrameLayout)this.findViewById(R.id.enter_yaokong_fl);
		anFangFl = (FrameLayout)this.findViewById(R.id.enter_anfang_fl);
		huanJingFl.setOnClickListener(this);
		yaoKongFl.setOnClickListener(this);
		anFangFl.setOnClickListener(this);
		wendu_bt = (FrameLayout) this.findViewById(R.id.wendu_bt);
		wendu_bt.setOnClickListener(this);
	}
	
	@Override
    protected void onResume() {
    	//����Ϊ��activity��handler
		Util.uiHandler = myHandler;
        Util.whichBlock = "09";//��ʪ�Ȱ��ӽڵ��ַ
    	super.onResume();
    }
	
	
	public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
	
	public void changeActivity(@SuppressWarnings("rawtypes") Class cls) {
		Intent intent = new Intent(this,cls);
		this.startActivity(intent);
	}

	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {
		case R.id.enter_huanjing_fl:
			changeActivity(JianKongActivity.class);
			break;
		case R.id.enter_yaokong_fl:
			changeActivity(YaoKongActivity.class);
			break;
		case R.id.enter_anfang_fl:
			changeActivity(AnFangActivity.class);
			break;
		case R.id.wendu_bt:
			int datas[] = {addr1,addr2,0x09,0x4E,0xAA,0xAA,0xAA};
    		sendMsgToService(datas,Util.JIAJU);
			break;
		}
	}
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
    private void sendMsgToService(int datas[],int what){
			if(MainZigBeeService.myHandler!=null){
//				if(a){
					Message msg = Message.obtain();
					msg.what = what;
					msg.obj = datas;
					MainZigBeeService.myHandler.sendMessage(msg);
//                    showMsg(anniu);
                   
//				}else{
//					showMsg("�޷���ȡ������ư�����ڵ�ַ���������ڸð�δ����");
//				}
			}else{
				showMsg("����δ��������������û���豸����");
			}
	}
}

