package com.dapeng.activity;

import java.util.ArrayList;
import java.util.HashMap;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.dapeng.R;
import com.dapeng.util.AChartView;
import com.dapeng.util.NowTime;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;

@SuppressLint("HandlerLeak")
public class QiTiActivity extends Activity implements OnClickListener{
	ListView trqListView;
	SimpleAdapter sAdapter;
	TextView addressTv,netNumTv,singleTv,showNdTv;
	Button back;
	LinearLayout trqLinell;
	//����ͼ����
	AChartView acd;
	
	int currtIntNongDu =0 ;
	float nongdufloat = 8f;
	
	public static final int GETLRTB = 0;//�¶����ӵ�ĳ�ʼֵ
	public static final int INIT = 1;//��ʼ
	public static final int ADD = 2;//����
	public static final int MINU = 3;//����
	boolean isShow = true;
	Handler gzHandler = new Handler(){//�����¶ȼ�
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case GETLRTB://�¶����ӵ�ĳ�ʼֵ
				break;
			case INIT://��ʼ
				break;
			case ADD://����
				break;
			case MINU://����
				break;
			}
		};
	};
	Handler myHandler = new Handler(){//���պ�̨��������
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.FDDATA:
				parseData(msg.obj.toString());
				break;
			case Util.NETADRR:
				addressTv.setText("���ڵ�ַ��"+msg.obj);
				break;
			case Util.NETNUM:
				netNumTv.setText("����ţ�"+msg.obj);
				break;
			case Util.SINGLENUM:
				singleTv.setText("�ŵ��ţ�"+msg.obj);
				break;
			}
		}
	};
	
	//������Ȼ������
	private void parseData(String dataStr){
		 try {
//			 String msg[]= dataStr.split(" ");
//			 byte data[] = HexDump.hexStringToByteArray(msg[5]+msg[6]);
//			 int trq = data[0]+data[1];
			 String msg[]= dataStr.split(" ");
			 byte data[] = HexDump.hexStringToByteArray(msg[5]+msg[6]);
			//�п��ܻ���ֳ���128������  �ڴ˻��Ϊ���� ��Ҫת��Ϊ0-256֮�������
			int numInt[] = new int[2];
			numInt[0] = data[0];
			numInt[1] = data[1];
			if(data[0]<0){
				numInt[0] = 256+data[1];
			}
			if(data[1]<0){
				numInt[1] = 256+data[1];
			}
			 int trq = numInt[0]*256+numInt[1];
			 acd.updateChart(trq);
			 getDataShowList(trq);
			 showNdTv.setText(""+trq);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	ArrayList<HashMap<String,String>> data = new ArrayList<HashMap<String,String>>(); 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_qt);
		back = (Button)this.findViewById(R.id.trq_back);
		back.setOnClickListener(this);
		showNdTv = (TextView)this.findViewById(R.id.trq_nd_tv);
		addressTv = (TextView)this.findViewById(R.id.trq_addr_tv);
		netNumTv = (TextView)this.findViewById(R.id.trq_netNum_tv);
		singleTv = (TextView)this.findViewById(R.id.trq_singelNum_tv);
		trqListView = (ListView)this.findViewById(R.id.trq_listView1);
		trqLinell = (LinearLayout)this.findViewById(R.id.trq_line_ll);
//		trqTv.setText("��ǰŨ�ȣ�28.6ppm");
		showNdTv.setText("0");
		String from[] = {"left","right"};
		int to[] = {R.id.item_textView1,R.id.item_textView2};
		sAdapter = new SimpleAdapter(this, data, R.layout.list_item, from, to);
		trqListView.setAdapter(sAdapter);
		
		currtIntNongDu = Math.round(nongdufloat);
		//��ʼ������ͼ
		acd = new AChartView(this,trqLinell,"��Ȼ��Ũ������ͼ","ʱ�� S","Ũ�� ppm",0,300,0,1000);
		acd.updateChart(0);
		super.onCreate(savedInstanceState);
	}
	
	@Override
    protected void onResume() {
    	//����Ϊ��activity��handler
		Util.uiHandler = myHandler;
        Util.whichBlock = "05";//��Ȼ�����ӽڵ�
    	super.onResume();
    }
	
	@Override
	protected void onPause() {
		isShow = false;
		super.onPause();
	}
	
	
	public void sendMsg(int what,int arg1){
		Message msg = Message.obtain();
		msg.what = what;
		msg.arg1 = arg1;
		if(gzHandler!=null){
			gzHandler.sendMessage(msg);
		}
	}
	
	//���list������
	private void getDataShowList(float wendu){
		HashMap<String,String> hmdata = new HashMap<String, String>();
		hmdata.put("left", NowTime.getNowTime());
		hmdata.put("right", wendu+"");
		data.add(hmdata);
		sAdapter.notifyDataSetChanged();
		trqListView.setSelection(data.size());
	}
	
	@Override
	public void onClick(View v) {
		isShow = false;
		this.finish();
	}
}
