package com.dapeng.activity;


import java.util.Calendar;
import java.util.Hashtable;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.util.DrawView;
import com.dapeng.util.Util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class WltpActivity extends Activity{
    FrameLayout line_1,line_2,line_3,line_4,line_5,line_6,line_7,line_8,line_9,line_10;
    //�����ж������Ƿ����
	boolean l_1 = false,l_2 = false,l_3 = false,l_4 = false,l_5 = false,l_6 = false,l_7 = false,l_8 = false,l_9 = false,l_10 = false;
	//�����жϵ�ǰ�ڵ��Ƿ����
//	boolean b1 = false,b2 = false,b3 = false,b8 = false,b5 = false,b7 = false,b6 = false,b40 = false,b41 = false,b4 = false;
	//��������ʱ�жϽڵ��Ƿ����
	boolean a2 = false,a3 = false,a9 = false,a5 = false,a7 = false,a40 = false,a41 = false,a4 = false;
	Calendar start,start2,start3,start4,start5,start6,start7,start8,start9,start10;
	Calendar end,end2,end3,end4,end5,end6,end7,end8,end9,end10;
	long startTime;
	long endTime;
	
	ImageView xietiaoqi_imageview,zhongduan_imageview1,zhongduan_imageview2,zhongduan_imageview3,zhongduan_imageview4,zhongduan_imageview5,
	zhongduan_imageview6,zhongduan_imageview7,zhongduan_imageview8,zhongduan_imageview9,zhongduan_imageview10;
	TextView xietiaoqi_text1,xietiaoqi_text2,xietiaoqi_text3;
	TextView zhongduan1_text1,zhongduan1_text2,zhongduan1_text3;
	TextView zhongduan2_text1,zhongduan2_text2,zhongduan2_text3;
	TextView zhongduan3_text1,zhongduan3_text2,zhongduan3_text3;
	TextView zhongduan4_text1,zhongduan4_text2,zhongduan4_text3;
	TextView zhongduan5_text1,zhongduan5_text2,zhongduan5_text3;
	TextView zhongduan6_text1,zhongduan6_text2,zhongduan6_text3;
	TextView zhongduan7_text1,zhongduan7_text2,zhongduan7_text3;
	TextView zhongduan8_text1,zhongduan8_text2,zhongduan8_text3;
	TextView zhongduan9_text1,zhongduan9_text2,zhongduan9_text3;
	TextView zhongduan10_text1,zhongduan10_text2,zhongduan10_text3;
	Hashtable table=new Hashtable();//�ڵ��ַ-λ��
	Handler myHandler = new Handler(){//���պ�̨��������
		public void handleMessage(android.os.Message msg) {
		
			switch (msg.what) {
			case Util.FDDATA:
				if(msg.obj!=null){
					 String msgStr = (String)msg.obj;
					 String datas[] = msgStr.split(" ");
				     xietiaoqi_imageview.setBackgroundResource(R.drawable.r);
					 xietiaoqi_text1.setText("Э����");
					 xietiaoqi_text2.setText("���ڵ�ַ");
					 xietiaoqi_text3.setText("0000");
					 if(datas[0].equals("FD") &&(datas[4].equals("02") || datas[4].equals("B1") || datas[4].equals("A8") || datas[4].equals("05") || datas[4].equals("09") )){										
						if(table.get(datas[4])!=null){
								
						}else{
						   drawpicture(datas);
						}
						
					}
					threeTime(datas);
				}else{
					System.out.println("û���ݡ�����������");
				}
				
				break;
			case Util.FCDATA:
				if(msg.obj!=null){
					 String msgStr = (String)msg.obj;
					 String datas[] = msgStr.split(" ");
				     xietiaoqi_imageview.setBackgroundResource(R.drawable.r);
					 xietiaoqi_text1.setText("Э����");
					 xietiaoqi_text2.setText("���ڵ�ַ");
					 xietiaoqi_text3.setText("0000");
					 if(datas[0].equals("FD") &&(datas[4].equals("02") || datas[4].equals("B1") || datas[4].equals("A8") || datas[4].equals("05") || datas[4].equals("09") )){										
						if(table.get(datas[4])!=null){
								
						}else{
						   drawpicture(datas);
						}
						
					}
					threeTime(datas);
				}else{
					System.out.println("û���ݡ�����������");
				}
				
				break;
			}
		}
	};
	private void drawpicture(String datas[]){
		System.out.println("������111111111111");
		System.out.println("�ڵ�="+datas[4]);
		String jiedian="";
        if(datas[4].equals("02")){//���ն�
			jiedian="���ն�";
		}else if(datas[4].equals("B1")){//���
			jiedian="�������";
		}else if(datas[4].equals("05")){//��Ȼ��
			jiedian="��Ȼ��";
		}else if(datas[4].equals("07")){//λ��
			jiedian="λ��";
		}else if(datas[4].equals("09")){//��ʪ��
			jiedian="��ʪ��";
		}else if(datas[4].equals("04")){//���ٶ�
			jiedian="���ٶ�";
		}else if(datas[4].equals("A8")){//����һ
			jiedian="����һ";
		}else if(datas[4].equals("41")){//���̶�
			jiedian="���̶�";
		} 
		if(l_1==false){
			line_1 = (FrameLayout) findViewById(id.line_1);
			DrawView draw1 = new DrawView(WltpActivity.this,330,3,90,20);
			line_1.addView(draw1);
			
			zhongduan1_text1.setText(jiedian);
			zhongduan1_text2.setText("���ڵ�ַ");
			zhongduan1_text3.setText(datas[17]+datas[18]);
			
			zhongduan_imageview1.setBackgroundResource(R.drawable.g);
			
			table.put(datas[4],"l_1");
			l_1=true;
		}else if(l_2==false){
			line_2 = (FrameLayout) findViewById(id.line_2);
		    DrawView draw2 = new DrawView(WltpActivity.this,329,4,160,70);
			line_2.addView(draw2);
			
			zhongduan2_text1.setText(jiedian);
			zhongduan2_text2.setText("���ڵ�ַ");
			zhongduan2_text3.setText(datas[17]+datas[18]);
			
			zhongduan_imageview2.setBackgroundResource(R.drawable.g);
			
			table.put(datas[4],"l_2");
			l_2=true;
		}else if(l_3==false){
			line_3 = (FrameLayout) findViewById(id.line_3);
			DrawView draw3 = new DrawView(WltpActivity.this,331,6,210,120);
			line_3.addView(draw3);
			
			zhongduan_imageview3.setBackgroundResource(R.drawable.g);
			
			zhongduan3_text1.setText(jiedian);
			zhongduan3_text2.setText("���ڵ�ַ");
			zhongduan3_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_3");
			l_3=true;
		}else if(l_4==false){
			line_4 = (FrameLayout) findViewById(id.line_4);
			DrawView draw4 = new DrawView(WltpActivity.this,332,7,260,170);
			line_4.addView(draw4);
			
			zhongduan_imageview4.setBackgroundResource(R.drawable.g);
			
			zhongduan4_text1.setText(jiedian);
			zhongduan4_text2.setText("���ڵ�ַ");
			zhongduan4_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_4");
			l_4=true;
		}else if(l_5==false){
			line_5 = (FrameLayout) findViewById(id.line_5);
			DrawView draw5 = new DrawView(WltpActivity.this,336,5,330,170);
			line_5.addView(draw5);
			
			zhongduan_imageview5.setBackgroundResource(R.drawable.g);
			
			zhongduan5_text1.setText(jiedian);
			zhongduan5_text2.setText("���ڵ�ַ");
			zhongduan5_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_5");
			l_5=true;
		}else if(l_6==false){
			line_6 = (FrameLayout) findViewById(id.line_6);
			DrawView draw6 = new DrawView(WltpActivity.this,340,3,390,170);
			line_6.addView(draw6);
			
			zhongduan_imageview6.setBackgroundResource(R.drawable.g);
			
			zhongduan6_text1.setText(jiedian);
			zhongduan6_text2.setText("���ڵ�ַ");
			zhongduan6_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_6");
			l_6=true;
		}else if(l_7==false){
			line_7 = (FrameLayout) findViewById(id.line_7);
			DrawView draw7 = new DrawView(WltpActivity.this,344,0,450,150);
			line_7.addView(draw7);
			
			zhongduan_imageview7.setBackgroundResource(R.drawable.g);
			
			zhongduan7_text1.setText(jiedian);
			zhongduan7_text2.setText("���ڵ�ַ");
			zhongduan7_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_7");
			l_7=true;
		}else if(l_8==false){
			line_8 = (FrameLayout) findViewById(id.line_8);
			DrawView draw8 = new DrawView(WltpActivity.this,349,0,510,120);
			line_8.addView(draw8);
			
			zhongduan_imageview8.setBackgroundResource(R.drawable.g);
			
			zhongduan8_text1.setText(jiedian);
			zhongduan8_text2.setText("���ڵ�ַ");
			zhongduan8_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_8");
			l_8=true;
		}else if(l_9==false){
			line_9 = (FrameLayout) findViewById(id.line_9);
			DrawView draw9 = new DrawView(WltpActivity.this,350,0,570,70);
			line_9.addView(draw9);
			
			zhongduan_imageview9.setBackgroundResource(R.drawable.g);
			
			zhongduan9_text1.setText(jiedian);
			zhongduan9_text2.setText("���ڵ�ַ");
			zhongduan9_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_9");
			l_9=true;
		}else if(l_10==false){
			line_10 = (FrameLayout) findViewById(id.line_10);
			DrawView draw10 = new DrawView(WltpActivity.this,350,1,628,20);
			line_10.addView(draw10);
			
			zhongduan_imageview10.setBackgroundResource(R.drawable.g);
			
			zhongduan10_text1.setText(jiedian);
			zhongduan10_text2.setText("���ڵ�ַ");
			zhongduan10_text3.setText(datas[17]+datas[18]);
			
			table.put(datas[4],"l_10");
			l_10=true;
		}
		System.out.println("jiedian="+jiedian);
		System.out.println("���ڵ�ַ="+datas[17]+datas[18]);
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		setContentView(R.layout.activity_wltp);
		super.onCreate(savedInstanceState);
//		line_1 = (FrameLayout) findViewById(id.line_1);
//		DrawView draw1 = new DrawView(WltpActivity.this,330,3,90,18);
//		line_1.addView(draw1);
//	    line_2 = (FrameLayout) findViewById(id.line_2);
//	    DrawView draw2 = new DrawView(WltpActivity.this,329,4,160,70);
//		line_2.addView(draw2);
//		line_3 = (FrameLayout) findViewById(id.line_3);
//		DrawView draw3 = new DrawView(WltpActivity.this,331,6,210,120);
//		line_3.addView(draw3);
//		line_4 = (FrameLayout) findViewById(id.line_4);
//		DrawView draw4 = new DrawView(WltpActivity.this,332,7,260,170);
//		line_4.addView(draw4);
//		line_5 = (FrameLayout) findViewById(id.line_5);
//		DrawView draw5 = new DrawView(WltpActivity.this,336,5,330,170);
//		line_5.addView(draw5);
//		line_6 = (FrameLayout) findViewById(id.line_6);
//		DrawView draw6 = new DrawView(WltpActivity.this,340,3,390,170);
//		line_6.addView(draw6);
//	    line_7 = (FrameLayout) findViewById(id.line_7);
//	    DrawView draw7 = new DrawView(WltpActivity.this,344,0,450,150);
//		line_7.addView(draw7);
//		line_8 = (FrameLayout) findViewById(id.line_8);
//		DrawView draw8 = new DrawView(WltpActivity.this,349,0,510,120);
//		line_8.addView(draw8);
//		line_9 = (FrameLayout) findViewById(id.line_9);
//		DrawView draw9 = new DrawView(WltpActivity.this,350,0,570,70);
//		line_9.addView(draw9);
//		line_10 = (FrameLayout) findViewById(id.line_10);
//		DrawView draw10 = new DrawView(WltpActivity.this,350,1,628,20);
//		line_10.addView(draw10);
		
		xietiaoqi_imageview = (ImageView) findViewById(id.xietiaoqi_imageview);
		zhongduan_imageview1 = (ImageView) findViewById(id.zhongduan_imageview1);
		zhongduan_imageview2 = (ImageView) findViewById(id.zhongduan_imageview2);
		zhongduan_imageview3 = (ImageView) findViewById(id.zhongduan_imageview3);
		zhongduan_imageview4 = (ImageView) findViewById(id.zhongduan_imageview4);
		zhongduan_imageview5 = (ImageView) findViewById(id.zhongduan_imageview5);
		zhongduan_imageview6 = (ImageView) findViewById(id.zhongduan_imageview6);
		zhongduan_imageview7 = (ImageView) findViewById(id.zhongduan_imageview7);
		zhongduan_imageview8 = (ImageView) findViewById(id.zhongduan_imageview8);
		zhongduan_imageview9 = (ImageView) findViewById(id.zhongduan_imageview9);
		zhongduan_imageview10 = (ImageView) findViewById(id.zhongduan_imageview10);
		
		xietiaoqi_text1 = (TextView) findViewById(id.xietiaoqi_text1);
		xietiaoqi_text2 = (TextView) findViewById(id.xietiaoqi_text2);
		xietiaoqi_text3 = (TextView) findViewById(id.xietiaoqi_text3);
		zhongduan1_text1 = (TextView) findViewById(id.zhongduan1_text1);
		zhongduan1_text2 = (TextView) findViewById(id.zhongduan1_text2);
		zhongduan1_text3 = (TextView) findViewById(id.zhongduan1_text3);
		zhongduan2_text1 = (TextView) findViewById(id.zhongduan2_text1);
		zhongduan2_text2 = (TextView) findViewById(id.zhongduan2_text2);
		zhongduan2_text3 = (TextView) findViewById(id.zhongduan2_text3);
		zhongduan3_text1 = (TextView) findViewById(id.zhongduan3_text1);
		zhongduan3_text2 = (TextView) findViewById(id.zhongduan3_text2);
		zhongduan3_text3 = (TextView) findViewById(id.zhongduan3_text3);
		zhongduan4_text1 = (TextView) findViewById(id.zhongduan4_text1);
		zhongduan4_text2 = (TextView) findViewById(id.zhongduan4_text2);
		zhongduan4_text3 = (TextView) findViewById(id.zhongduan4_text3);
		zhongduan5_text1 = (TextView) findViewById(id.zhongduan5_text1);
		zhongduan5_text2 = (TextView) findViewById(id.zhongduan5_text2);
		zhongduan5_text3 = (TextView) findViewById(id.zhongduan5_text3);
		zhongduan6_text1 = (TextView) findViewById(id.zhongduan6_text1);
		zhongduan6_text2 = (TextView) findViewById(id.zhongduan6_text2);
		zhongduan6_text3 = (TextView) findViewById(id.zhongduan6_text3);
		zhongduan7_text1 = (TextView) findViewById(id.zhongduan7_text1);
		zhongduan7_text2 = (TextView) findViewById(id.zhongduan7_text2);
		zhongduan7_text3 = (TextView) findViewById(id.zhongduan7_text3);
		zhongduan8_text1 = (TextView) findViewById(id.zhongduan8_text1);
		zhongduan8_text2 = (TextView) findViewById(id.zhongduan8_text2);
		zhongduan8_text3 = (TextView) findViewById(id.zhongduan8_text3);
		zhongduan9_text1 = (TextView) findViewById(id.zhongduan9_text1);
		zhongduan9_text2 = (TextView) findViewById(id.zhongduan9_text2);
		zhongduan9_text3 = (TextView) findViewById(id.zhongduan9_text3);
		zhongduan10_text1 = (TextView) findViewById(id.zhongduan10_text1);
		zhongduan10_text2 = (TextView) findViewById(id.zhongduan10_text2);
		zhongduan10_text3 = (TextView) findViewById(id.zhongduan10_text3);
		
		start = Calendar.getInstance();
		startTime = start.getTimeInMillis();
				
	}
	 public void threeTime(String datas[]){
		    if(datas[4].equals("02")){//���ն�
				a2=true;
			}else if(datas[4].equals("B1")){//�������
				a3=true;
			}else if(datas[4].equals("05")){//��Ȼ��
				a5=true;
			}else if(datas[4].equals("07")){//λ��
				a7=true;
			}else if(datas[4].equals("09")){//��ʪ��
				a9=true;
			}else if(datas[4].equals("04")){//���ٶ�
				a4=true;
			}else if(datas[4].equals("A8")){//����һ
				a40=true;
			}else if(datas[4].equals("41")){//���̶�
				a41=true;
			}
		    end = Calendar.getInstance();
			endTime = end.getTimeInMillis();
			System.out.println("endTime-startTime="+(endTime-startTime));
			if(endTime-startTime>=3000){
				System.out.println("����");				
				if(a2==true){
			       a2=false;
				}else{				   
				  shanchu("02");
				  System.out.println("b2����");
				 
				}
				if(a3==true){
				   a3=false;				   
				}else{				  
				   shanchu("B1");
				   System.out.println("b3����");
				  
			    }
				if(a5==true){
				   a5=false;
				}else{
				   shanchu("05");				  
				   System.out.println("b5����");
				}
				if(a7==true){
				   a7=false;				   
				}else{
				   shanchu("07");				   
				   System.out.println("b7����");
				}
			    if(a9==true){
					a9=false;
				}else{
					shanchu("09");
					System.out.println("b9����");
			    }

				if(a4==true){
					a4=false;
				}else{
					shanchu("04");
					System.out.println("b4����");
				}	
				if(a40==true){
					a40=false;				   
				}else{
					shanchu("A8");
					System.out.println("b40����");
							  
				}
			    if(a41==true){
					a41=false;
			    }else{
			    	shanchu("41");
			    	System.out.println("b41����");
				}
				startTime=endTime;
			}
	  }
	 private void shanchu(String aa){
		
		 if(table.get(aa)!=null){
			 String weizhi=table.get(aa).toString();
			 System.out.println("weizi22222222222222="+weizhi);
			 if(weizhi.equals("l_1")){
				 line_1.removeAllViews();
				 zhongduan_imageview1.setBackgroundResource(0);
				 zhongduan1_text1.setText("");
				 zhongduan1_text2.setText("");
				 zhongduan1_text3.setText("");
				 l_1=false;				 
			 }else if(weizhi.equals("l_2")){
				 line_2.removeAllViews();
				 zhongduan_imageview2.setBackgroundResource(0);
				 zhongduan2_text1.setText("");
				 zhongduan2_text2.setText("");
				 zhongduan2_text3.setText("");
				 l_2=false;
			 }else if(weizhi.equals("l_3")){
				 line_3.removeAllViews();
				 zhongduan_imageview3.setBackgroundResource(0);
				 zhongduan3_text1.setText("");
				 zhongduan3_text2.setText("");
				 zhongduan3_text3.setText("");
				 l_3=false;
			 }else if(weizhi.equals("l_4")){
				 line_4.removeAllViews();
				 zhongduan_imageview4.setBackgroundResource(0);
				 zhongduan4_text1.setText("");
				 zhongduan4_text2.setText("");
				 zhongduan4_text3.setText("");
				 l_4=false;
			 }else if(weizhi.equals("l_5")){
				 line_5.removeAllViews();
				 zhongduan_imageview5.setBackgroundResource(0);
				 zhongduan5_text1.setText("");
				 zhongduan5_text2.setText("");
				 zhongduan5_text3.setText("");
				 l_5=false;
			 }else if(weizhi.equals("l_6")){
				 line_6.removeAllViews();
				 zhongduan_imageview6.setBackgroundResource(0);
				 zhongduan6_text1.setText("");
				 zhongduan6_text2.setText("");
				 zhongduan6_text3.setText("");
				 l_6=false;
			 }else if(weizhi.equals("l_7")){
				 line_7.removeAllViews();
				 zhongduan_imageview7.setBackgroundResource(0);
				 zhongduan7_text1.setText("");
				 zhongduan7_text2.setText("");
				 zhongduan7_text3.setText("");
				 l_7=false;
			 }else if(weizhi.equals("l_8")){
				 line_8.removeAllViews();
				 zhongduan_imageview8.setBackgroundResource(0);
				 zhongduan8_text1.setText("");
				 zhongduan8_text2.setText("");
				 zhongduan8_text3.setText("");
				 l_8=false;
			 }else if(weizhi.equals("l_9")){
				 line_9.removeAllViews();
				 zhongduan_imageview9.setBackgroundResource(0);
				 zhongduan9_text1.setText("");
				 zhongduan9_text2.setText("");
				 zhongduan9_text3.setText("");
				 l_9=false;
			 }else if(weizhi.equals("l_10")){
				 line_10.removeAllViews();
				 zhongduan_imageview10.setBackgroundResource(0);
				 zhongduan10_text1.setText("");
				 zhongduan10_text2.setText("");
				 zhongduan10_text3.setText("");
				 l_10=false;
			 }
			 table.remove(aa);
		 }
	 }
	@Override
    protected void onResume() { 
    	//����Ϊ��activity��handler 
		Util.uiHandler = myHandler;
		Util.whichBlock = "showdata";//Э�������ӽڵ��ַ
		super.onResume();
	}

}
