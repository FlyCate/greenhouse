package com.dapeng.activity;

import com.dapeng.R;
import com.dapeng.R.id;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class StartActivity2 extends Activity implements OnClickListener{
	Button chuanganqiBt,fengjiBt,shebeiBt,autoBt,historyBt,shexiangjiBt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_start2);
		chuanganqiBt = (Button) findViewById(id.two_cgq);
		chuanganqiBt.setOnClickListener(this);
		fengjiBt = (Button) findViewById(id.two_fengji);
		fengjiBt.setOnClickListener(this);
		shebeiBt = (Button) findViewById(id.two_shebei);
		shebeiBt.setOnClickListener(this);
		autoBt = (Button) findViewById(id.two_auto);
		autoBt.setOnClickListener(this);
		historyBt = (Button) findViewById(id.two_history);
		historyBt.setOnClickListener(this);
		shexiangjiBt = (Button) findViewById(id.two_shexiangji);
		shexiangjiBt.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.two_cgq://������
			changeActivity(ChuanGanQiActivity.class);
			break;
		case R.id.two_fengji://�������
			changeActivity(FengShanActivity.class);
			break;
		case R.id.two_shebei://�豸����
			changeActivity(JiaDianActivity.class);
			break;
		case R.id.two_auto:
			changeActivity(AutoActivity.class);
			break;
		case R.id.two_history:
			changeActivity(HistoricalDataActivity.class);
			break;
		case R.id.two_shexiangji:
			try{
				Intent intent = new Intent(Intent.ACTION_MAIN);
				ComponentName componentName = new ComponentName("com.easyn.EasyN_P","com.easyn.P2PCam264.SplashScreenActivity");
				intent.setComponent(componentName);
				startActivity(intent);
			}catch(Exception e){
				showMsg("δ��װ������������!");
			}
			

			break;
		}
	}
	private void changeActivity(Class cls){
		Intent intent = new Intent(this, cls);
		this.startActivity(intent);
		
	}
	public void showMsg(String text){
		Toast.makeText(this, text, 10000).show();
	}

}
