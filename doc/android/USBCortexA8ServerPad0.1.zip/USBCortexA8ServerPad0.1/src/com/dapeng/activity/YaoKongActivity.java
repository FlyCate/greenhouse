package com.dapeng.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.util.Util;


@SuppressLint("HandlerLeak")
public class YaoKongActivity extends Activity implements OnClickListener{
	private FrameLayout kongtiaoFl,xiyijiFl,bingxiangFl,dianshiFl,dvdFl,yinxiangFl,autoFl;
    private TextView titleView;
    Handler myHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.ALLDATA:
				
				break;
			case Util.FDDATA:
				
				break;
			}
		}
	};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yaokong);
        
        kongtiaoFl = (FrameLayout)this.findViewById(R.id.yaokong_kongtiao_fl);
        xiyijiFl = (FrameLayout)this.findViewById(R.id.yaokong_kaiguanliang_fl);
//        bingxiangFl = (FrameLayout)this.findViewById(R.id.yaokong_bingxiang_fl);
        dianshiFl = (FrameLayout)this.findViewById(R.id.yaokong_dianshiji_fl);
        dvdFl = (FrameLayout)this.findViewById(R.id.yaokong_dvd_fl);
        yinxiangFl = (FrameLayout)this.findViewById(R.id.yaokong_yinxiang_fl);
        autoFl = (FrameLayout)this.findViewById(R.id.yaokong_auto_fl);
        kongtiaoFl.setOnClickListener(this);
        xiyijiFl.setOnClickListener(this);
//        bingxiangFl.setOnClickListener(this);
        dianshiFl.setOnClickListener(this);
        dvdFl.setOnClickListener(this);
        yinxiangFl.setOnClickListener(this);
        autoFl.setOnClickListener(this);
        
//        titleView = (TextView)this.findViewById(R.id.yaokong_title_tv);
//        if(this.getIntent().hasExtra("name")){
//	        String text = (String)this.getIntent().getCharSequenceExtra("name");
//	        titleView.append("-"+text);
//        }
    }
    
    @Override
    protected void onResume() {
    	//����Ϊ��activity��handler
    	Util.uiHandler = myHandler;
    	super.onResume();
    }

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.yaokong_kongtiao_fl:
			changeActivity(KongTiaoActivity.class,"");
			break;
		case R.id.yaokong_kaiguanliang_fl:
			changeActivity(KaiGuanLiangKongZhiActivity.class,"");
			break;
//		case R.id.yaokong_bingxiang_fl:
//			changeActivity(ChuangLianActivity.class,"");
//			break;
		case R.id.yaokong_dianshiji_fl:
			changeActivity(DianShiActivity.class,"���ӻ�");
			break;
		case R.id.yaokong_dvd_fl:
			changeActivity(DVDActivity.class,"DVD");
			break;
		case R.id.yaokong_yinxiang_fl:
			changeActivity(YinXiangActivity.class,"����");
			break;
		case R.id.yaokong_auto_fl:
			changeActivity(AutoActivity.class,"�Զ�����");
			break;
		}
		
	}
	
	//������ת
	private void changeActivity(@SuppressWarnings("rawtypes") Class cls,String data){
		Intent intent = new Intent(this, cls);
		intent.putExtra("form", data);
		intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		this.startActivity(intent);
	}
	
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
}
