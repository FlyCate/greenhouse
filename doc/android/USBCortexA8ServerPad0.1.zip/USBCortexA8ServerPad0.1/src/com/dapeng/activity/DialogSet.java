package com.dapeng.activity;

import android.app.Dialog;
import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.util.SavePerfrence;
import com.dapeng.util.Util;

public class DialogSet extends Dialog implements android.view.View.OnClickListener{
	private View diaView;
	Spinner spinnerRate,spinnerChuanKou,spinnerShuJuWei,spinnerJiOu,spinnerTingZhi,spinnerBoxNum;
	Button cancel,confirm,title;
	SavePerfrence spf;
	Context context;
	public DialogSet(Context context,String text) {
		super(context, R.style.setdialog);
		this.context = context;
		spf = new SavePerfrence(context);
		diaView = View.inflate(context, R.layout.dialog_setting, null);
		this.setContentView(diaView);
		initSpinner(diaView);
		title = (Button)this.findViewById(R.id.dialog_set_title);
		title.setText(text);
		cancel = (Button)this.findViewById(R.id.dialog_cancel_btn);
		cancel.setOnClickListener(this);
		confirm = (Button)this.findViewById(R.id.dialog_queding_btn);
		confirm.setOnClickListener(this);
		
		this.show();
	}
	//1200��2400��4800��9600��19200��28400��57600��  115200
	String rate[] = {"1200","2400","4800","9600","19200","38400","57600","115200"};
	String chuanKou[] = {"ttyUsb0","ttyUsb1","ttyUsb2"};
	String shuJuWei[] = {"0","1","2","3","4","5","6","7","8"};
	
	String jiOu[] = {"NONE","ODD","EVEN","MARK","SPACE"};
	int jiOuData[] = {0,1,2,3,4};
	
	String tingZhi[] = {"1","1.5","2"};
	int tingZhiData[] = {1,3,2};
	String boxNum[] = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"};
	int boxNumData[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
	private void initSpinner(View v){
		spinnerRate = (Spinner)v.findViewById(R.id.dialog_spinner_rate);
		spinnerRate.setTag("rate");
		spinnerChuanKou = (Spinner)v.findViewById(R.id.dialog_spinner_chuankou);
		spinnerChuanKou.setTag("ck");
		spinnerShuJuWei = (Spinner)v.findViewById(R.id.dialog_spinner_shujuwei);
		spinnerShuJuWei.setTag("sjw");
		spinnerJiOu = (Spinner)v.findViewById(R.id.dialog_spinner_jiou);
		spinnerJiOu.setTag("jo");
		spinnerTingZhi = (Spinner)v.findViewById(R.id.dialog_spinner_tingzhiwei);
		spinnerTingZhi.setTag("tz");		

		//����������
		ArrayAdapter<String> saRate = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, rate);  
		saRate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerRate.setAdapter(saRate);
		//��������
		ArrayAdapter<String> saChuanKou = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, chuanKou);  
		saChuanKou.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerChuanKou.setAdapter(saChuanKou);
		//����λ����
		ArrayAdapter<String> saShuJuWei = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, shuJuWei);  
		saShuJuWei.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerShuJuWei.setAdapter(saShuJuWei);
		//��ż����
		ArrayAdapter<String> saJiOu = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, jiOu);  
		saJiOu.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerJiOu.setAdapter(saJiOu);
		//ֹͣλ����
        ArrayAdapter<String> saTingZhi = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, tingZhi);  
        saTingZhi.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTingZhi.setAdapter(saTingZhi);
    	
        
        spinnerRate.setSelection(5);
        spinnerChuanKou.setSelection(0);
        spinnerShuJuWei.setSelection(8);
        spinnerJiOu.setSelection(0);
        spinnerTingZhi.setSelection(0);
      
        setData();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.dialog_cancel_btn:
			this.cancel();
			break;

		case R.id.dialog_queding_btn:
			setData();
			this.cancel();
			break;
		}
	}
	
	private void setData(){
		Util.rate = Integer.parseInt(rate[spinnerRate.getSelectedItemPosition()]);
		Util.dataBits = Integer.parseInt(shuJuWei[spinnerShuJuWei.getSelectedItemPosition()]);
		Util.jiou = jiOuData[spinnerJiOu.getSelectedItemPosition()];
		Util.stopBit= tingZhiData[spinnerTingZhi.getSelectedItemPosition()];

    }
	
	
}
