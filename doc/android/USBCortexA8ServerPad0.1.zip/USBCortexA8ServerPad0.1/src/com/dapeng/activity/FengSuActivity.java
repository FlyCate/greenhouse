package com.dapeng.activity;


import java.util.ArrayList;
import java.util.HashMap;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.util.AChartView;
import com.dapeng.util.BiaoLineView;
import com.dapeng.util.NowTime;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class FengSuActivity extends Activity implements OnClickListener{
  //  ImageView 
	ListView fengsuListView;
	FrameLayout fengsuAddFL;
	LinearLayout fengsuLinell,zhizhen;
	ImageView fengsuIv;
	Button back;
	TextView fengsuTv; 
	//list������
	SimpleAdapter sAdapter;
	//����ͼ����
	AChartView acd;
	float stopx=135,stopy=2;
	int r = 78;
	Handler myHandler = new Handler(){//���պ�̨��������
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.FDDATA:				
				parseFengSu((String)msg.obj);				
				break;
			}
		}
	};
	private void parseFengSu(String str){
		String datas[] = str.split(" ");
		
		byte fengsuByte[] = HexDump.hexStringToByteArray(datas[5]+datas[6]+datas[7]+datas[8]);
		int fengsu = (fengsuByte[0]*256+fengsuByte[1])/100;
		int fengxiang = (fengsuByte[2]*256+fengsuByte[3])/100;
		//�����ı���Ϣ
		fengsuTv.setText("��ǰ���٣�"+fengsu+"��");
		//��������ͼ
		acd.updateChart(fengsu);
		//����list
		getDataShowList(fengsu);
	}
	ArrayList<HashMap<String,String>> data = new ArrayList<HashMap<String,String>>(); 
	//���list������
	private void getDataShowList(double wendu){
		HashMap<String,String> hmdata = new HashMap<String, String>();
		hmdata.put("left", NowTime.getNowTime());
		hmdata.put("right", wendu+"");
		data.add(hmdata);
		sAdapter.notifyDataSetChanged();
		fengsuListView.setSelection(data.size());
	}
	@Override
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_fengsu);
    	
		 fengsuListView = (ListView) findViewById(R.id.fengsu_listView1);
		 fengsuLinell = (LinearLayout) findViewById(R.id.fengsu_line_ll);
		 zhizhen = (LinearLayout) findViewById(R.id.fengsu_zhizhen);
		 fengsuTv = (TextView) findViewById(id.fengsu_textView);
		 fengsuTv.setText("��ǰ���٣�0m/s");
		 back = (Button) findViewById(id.fengsu_back);
		 back.setOnClickListener(this);
		 String from[] = {"left","right"};
		 int to[] = {R.id.item_textView1,R.id.item_textView2};
		 sAdapter = new SimpleAdapter(this, data, R.layout.list_item, from, to);
		 fengsuListView.setAdapter(sAdapter);
			//��ʼ������ͼ
		 acd = new AChartView(this,fengsuLinell,"��������ͼ","ʱ�� S","�ٶ�m/s",0,300,0,100);
		 acd.updateChart(0);
		 
		 zhizhen = (LinearLayout) findViewById(id.fengsu_zhizhen);
		 stopx=(float) Math.sin(Math.toRadians(360/1600.0*800))*r;
		 stopy=(float) Math.cos(Math.toRadians(360/1600.0*800))*r;
		
		 BiaoLineView lineview = new BiaoLineView(FengSuActivity.this,135,120,135-stopx,120+stopy);
		 zhizhen.addView(lineview);

    }
	@Override
	public void onClick(View arg0) {
		this.finish();
		
			
	}

}
