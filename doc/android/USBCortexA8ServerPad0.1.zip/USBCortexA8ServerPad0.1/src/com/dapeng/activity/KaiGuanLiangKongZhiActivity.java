
package com.dapeng.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;



@SuppressLint("HandlerLeak")
public class KaiGuanLiangKongZhiActivity extends Activity implements OnClickListener{
	//��N����ʾ���ֹͣ��������F����ʾ��ƿ�ʼ������
	private Button deng1,deng2,deng3,chuanglian,luodideng,hongwai,dianfanbao,weibolu,jiashiqi,autowendu,autoshidu,autoguangzhao;
	private ImageView jiashiqiIv, deng1Iv,deng2Iv,deng3Iv,chuanglianIv,luodidengIv,dianfanbaoIv,weiboluIv,hongwaiIv;
	private EditText autowenduEt,autoshiduEt,autoguangzhaoEt;
	
	int dengAddr1 = 0,dengAddr2 = 0;
	int dwjAddr1 = 0,dwjAddr2 = 0;//�緹�� ΢��¯ ��ʪ��
	int cllddAddr1 = 0,cllddAddr2 = 0;//���� ��ص�
	
	int a = 0,b=0,c = 0,d = 0;
    Handler myHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.ALLDATA:
				
				break;
			case Util.FDDATA:
				 String res = ((String)msg.obj).trim();
				
				 if(res.contains("\r\n")){
					 String fds[] = res.split("\r\n");
					 for(int i = 0;i<fds.length;i++){
						 paresData(fds[i]);
						 System.out.println("1111111111111111fds[i]"+fds[i]);
					 }
				 }else{
					 paresData(res);
				 }
				break;
			}
		}
	};
	
	private void paresData(String msg){
		 String msgs[] = msg.trim().split(" ");
		 byte []bb = HexDump.hexStringToByteArray(msgs[17]+msgs[18]);
         Util.addr1 = bb[0];//ʮ����
         Util.addr2 = bb[1];
         if("A6".equals(msgs[4])){
        	 cllddAddr1 = bb[0];
        	 cllddAddr2 = bb[1];
        	 
        	 String clStr = msgs[5];
        	 String lddStr = msgs[6];
        	 String hongwaiStr = msgs[7];
        	 if(HexDump.hexStringToByteArray(clStr)[0] == 'F'){
        		 chuanglianIv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 chuanglianIv.setImageResource(R.drawable.design_icon_on);
        	 }
        	 if(HexDump.hexStringToByteArray(lddStr)[0] == 'F'){
        		 luodidengIv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 luodidengIv.setImageResource(R.drawable.design_icon_on);
        	 }
        	 if(HexDump.hexStringToByteArray(hongwaiStr)[0] == 'F'){
        		 hongwaiIv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 hongwaiIv.setImageResource(R.drawable.design_icon_on);
        	 }
         }else if("A7".equals(msgs[4])){
        	 dwjAddr1 = bb[0];
        	 dwjAddr2 = bb[1];
//        	 String dfbStr = msgs[5];
//        	 String wblStr = msgs[6];
//        	 String jsqStr = msgs[7];
        	 String clStr = msgs[5];
        	 String lddStr = msgs[6];
        	 String hongwaiStr = msgs[7];
        	 if(HexDump.hexStringToByteArray(clStr)[0] == 'F'){
        		 dianfanbaoIv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 dianfanbaoIv.setImageResource(R.drawable.design_icon_on);
        	 }
        	 if(HexDump.hexStringToByteArray(lddStr)[0] == 'F'){
        		 weiboluIv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 weiboluIv.setImageResource(R.drawable.design_icon_on);
        	 }
        	 if(HexDump.hexStringToByteArray(hongwaiStr)[0] == 'F'){
        		 jiashiqiIv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 jiashiqiIv.setImageResource(R.drawable.design_icon_on);
        	 }
         }else if("A8".equals(msgs[4])){
        	 dengAddr1 = bb[0];
        	 dengAddr2 = bb[1];
//        	 String deng1 = msgs[5];
//        	 String deng2 = msgs[6];
//        	 String deng3 = msgs[7];
        	 String clStr = msgs[5];
        	 String lddStr = msgs[6];
        	 String hongwaiStr = msgs[7];
        	 if(HexDump.hexStringToByteArray(clStr)[0] == 'F'){
        		 deng1Iv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 deng1Iv.setImageResource(R.drawable.design_icon_on);
        	 }
        	 if(HexDump.hexStringToByteArray(lddStr)[0] == 'F'){
        		 deng2Iv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 deng2Iv.setImageResource(R.drawable.design_icon_on);
        	 }
        	 if(HexDump.hexStringToByteArray(hongwaiStr)[0] == 'F'){
        		 deng3Iv.setImageResource(R.drawable.design_icon_off);
        	 }else{
        		 deng3Iv.setImageResource(R.drawable.design_icon_on);
        	 }
         }
//         else if("A9".equals(msgs[4])){
//        	 dengAddr1 = bb[0];
//        	 dengAddr2 = bb[1];
//         }
	}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kaiguanliangkongzhi);
        initView();
//        String urlPath = "lx=jsq&bn="+Util.boxNum;
//        Util.isNeedConn = false;
//		Util.bindMyService(this,urlPath);
//		startGetFD();
    }
    
//    boolean isGetFD = true;
//    private void startGetFD(){
//    	new Thread(){
//    		public void run(){
//    			while(isGetFD){
//	    			try {
//						String urlPath = "rdf?action=read&lx=jsq&bn="+Util.boxNum;
//						new Thread(new DownLoadRunnable(myHandler,urlPath,3)).start();
//						urlPath = "rdf?action=read&lx=fs&bn="+Util.boxNum;
//						new Thread(new DownLoadRunnable(myHandler,urlPath,3)).start();
//						urlPath = "rdf?action=read&lx=wbl&bn="+Util.boxNum;
//						new Thread(new DownLoadRunnable(myHandler,urlPath,3)).start();
////						urlPath = "rdf?action=read&lx=dd&bn="+Util.boxNum;
////						new Thread(new DownLoadRunnable(myHandler,urlPath,3)).start();
//						Thread.sleep(1000*2);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//    			}
//    		}
//    	}.start();
//    }
    
    private void initView(){
    	deng1Iv = (ImageView)this.findViewById(R.id.kg_deng_one_iv);deng1Iv.setTag(0);
    	deng2Iv = (ImageView)this.findViewById(R.id.kg_deng_two_iv);deng2Iv.setTag(0);
    	deng3Iv = (ImageView)this.findViewById(R.id.kg_deng_three_iv);deng3Iv.setTag(0);
    	
    	chuanglianIv = (ImageView)this.findViewById(R.id.kg_chuanglian_iv);chuanglianIv.setTag(0);
    	luodidengIv = (ImageView)this.findViewById(R.id.kg_luodideng_iv);luodidengIv.setTag(0);
    	hongwaiIv = (ImageView)this.findViewById(R.id.kg_rentihongwai_iv);hongwaiIv.setTag(0);
    	
    	dianfanbaoIv = (ImageView)this.findViewById(R.id.kg_dianfanbao_iv);dianfanbaoIv.setTag(0);
    	weiboluIv = (ImageView)this.findViewById(R.id.kg_wbl_iv);weiboluIv.setTag(0);
    	jiashiqiIv = (ImageView)this.findViewById(R.id.kg_jsq_iv);jiashiqiIv.setTag(0);
    	
//    	autowenduEt = (EditText)this.findViewById(R.id.kg_wenduauto_et);//autowenduIv.setTag(0);
//    	autoshiduEt = (EditText)this.findViewById(R.id.kg_shiduauto_et);//autoshiduIv.setTag(0);
//    	autoguangzhaoEt = (EditText)this.findViewById(R.id.kg_guangzhaoauto_et);//autoguangzhaoIv.setTag(0);
    	
    	jiashiqiIv = (ImageView)this.findViewById(R.id.kg_jsq_iv);jiashiqiIv.setTag(0);
    	
    	deng1 = (Button)this.findViewById(R.id.kg_deng_one_bt);
    	deng2 = (Button)this.findViewById(R.id.kg_deng_two_bt);
    	deng3 = (Button)this.findViewById(R.id.kg_deng_three_bt);
    	
    	chuanglian = (Button)this.findViewById(R.id.kg_chuanglian_bt);
    	luodideng = (Button)this.findViewById(R.id.kg_luodideng_bt);
    	hongwai = (Button)this.findViewById(R.id.kg_rentihongwai_bt);
    	
    	dianfanbao = (Button)this.findViewById(R.id.kg_dianfanbao_bt);
    	weibolu = (Button)this.findViewById(R.id.kg_wbl_bt);
    	jiashiqi = (Button)this.findViewById(R.id.kg_jsq_bt);
    	
//    	autowendu = (Button)this.findViewById(R.id.kg_wenduauto_bt);
//    	autoshidu = (Button)this.findViewById(R.id.kg_shiduauto_bt);
//    	autoguangzhao = (Button)this.findViewById(R.id.kg_guangzhaoauto_bt);
//    	
    	deng1.setOnClickListener(this);
    	deng2.setOnClickListener(this);
    	deng3.setOnClickListener(this);
    	chuanglian.setOnClickListener(this);
    	luodideng.setOnClickListener(this);
    	hongwai.setOnClickListener(this);
    	dianfanbao.setOnClickListener(this);
    	weibolu.setOnClickListener(this);
    	jiashiqi.setOnClickListener(this);
//    	autowendu.setOnClickListener(this);
//    	autoshidu.setOnClickListener(this);
//    	autoguangzhao.setOnClickListener(this);
    	
    	jiashiqiIv.setOnClickListener(this);
    }
    
    @Override
    protected void onResume() {
    	//����Ϊ��activity��handler
    	Util.uiHandler = myHandler;
    	Util.whichBlock = "showdata";
    	super.onResume();
    }
    
    @Override
	protected void onStop() {
		
		super.onStop();
	}
    
    @Override
    protected void onDestroy() {
//    	isGetFD = false;
//    	Util.unBindMyService(this);
    	super.onDestroy();
    }
    
    int addr1 = 0;
	int addr2 = 0;
	@Override
	public void onClick(View v) {
		
		switch (v.getId()) {
		case R.id.kg_chuanglian_bt:
			addr1 = cllddAddr1;
			addr2 = cllddAddr2;
			clickBt(0xA6,0,chuanglianIv);
			break;
		case R.id.kg_luodideng_bt:
			addr1 = cllddAddr1;
			addr2 = cllddAddr2;
			clickBt(0xA6,1,luodidengIv);
			break;
		case R.id.kg_rentihongwai_bt:
			addr1 = cllddAddr1;
			addr2 = cllddAddr2;
			clickBt(0xA6,2,hongwaiIv);
			break;
		case R.id.kg_dianfanbao_bt:
			addr1 = dwjAddr1;
			addr2 = dwjAddr2;
			clickBt(0xA7,0,dianfanbaoIv);
			break;
		case R.id.kg_wbl_bt:
			addr1 = dwjAddr1;
			addr2 = dwjAddr2;
			clickBt(0xA7,1,weiboluIv);
			break;
		case R.id.kg_jsq_bt:
			addr1 = dwjAddr1;
			addr2 = dwjAddr2;
			clickBt(0xA7,2,jiashiqiIv);
			break;
		case R.id.kg_deng_one_bt:
			addr1 = dengAddr1;
			addr2 = dengAddr2;
			clickBt(0xA8,0,deng1Iv);
			break;
		case R.id.kg_deng_two_bt:
			addr1 = dengAddr1;
			addr2 = dengAddr2;
			clickBt(0xA8,1,deng2Iv);
			break;
		case R.id.kg_deng_three_bt:
			addr1 = dengAddr1;
			addr2 = dengAddr2;
			clickBt(0xA8,2,deng3Iv);
			break;
//		case R.id.kg_wenduauto_bt:
////			clickBt(9,autowenduIv);
//			clickAutoBt(1);
//			break;
//		case R.id.kg_shiduauto_bt:
////			clickBt(10,autoshiduIv);
//			clickAutoBt(2);
//			break;
//		case R.id.kg_guangzhaoauto_bt:
////			clickBt(11,autoguangzhaoIv);
//			clickAutoBt(3);
//			break;
//		case R.id.kg_jiashiqi_iv:
//			int data = 0;
//			addr1 = jsqAddr1;
//			addr2 = jsqAddr2;
//			if((Integer)jiashiqiIv.getTag()==0){
//				jiashiqiIv.setTag(1);
//				jiashiqiIv.setImageResource(R.drawable.design_toggle_on);
//				//0xA4
//				data = 'F' & 0xff;
//			}else{
//				jiashiqiIv.setTag(0);
//				jiashiqiIv.setImageResource(R.drawable.design_toggle_off);
//				data = 'N' & 0xff;
//			}
//			int datas[] = {addr1,addr2,0xA6,data,0xAA,0xAA,0xAA};
//			Util.sendMsgToService(datas,Util.SENDDATATOSERVICE,KaiGuanLiangKongZhiActivity.this);
//			break;
		default:
			break;
		}
	}
	
	private void clickAutoBt(int num){//�Զ�����ģʽ�ķ��ͷ���
		int data = 0;
		if(num==1){
			String s = autowenduEt.getText().toString().trim()+"";
			if(s.length()>0){data = Integer.parseInt(s);}else{data = 20;}
		}else if(num==1){
			String s = autoshiduEt.getText().toString().trim()+"";
			if(s.length()>0){data = Integer.parseInt(s);}else{data = 20;}
		}else if(num==3){
			String s = autoguangzhaoEt.getText().toString().trim()+"";
			if(s.length()>0){data = Integer.parseInt(s);}else{data = 200;}
		}
		int subDatas[] = {0xAA,0xAA,0xAA,0XAA};
		subDatas[0] = num;
		subDatas[1] = data;
		int datas[] = {0xFC,subDatas[0],subDatas[1],subDatas[2],0xAA,0xFC};
//		Util.sendMsgToService(datas,Util.SENDAUTODATATOSERVICE,KaiGuanLiangKongZhiActivity.this);
	}
	
	private void clickBt(int jiedian,int num,ImageView showiV){
			if((Integer)showiV.getTag()==1){
				showiV.setTag(0);
				showiV.setImageResource(R.drawable.design_icon_off);
				int subDatas[] = {0xAA,0xAA,0XAA};
				subDatas[num] = 'F' & 0xff;
				int datas[] = {addr1,addr2,jiedian,subDatas[0],subDatas[1],subDatas[2],0xAA};
				sendMsgToService(datas,Util.JIAJU);
				System.out.println("jiedian111111111"+jiedian);
			}else{
				showiV.setTag(1);
				showiV.setImageResource(R.drawable.design_icon_on);
				int subDatas[] = {0xAA,0xAA,0XAA};
				subDatas[num] = 'N' & 0xff;
				int datas[] = {addr1,addr2,jiedian,subDatas[0],subDatas[1],subDatas[2],0xAA};
				sendMsgToService(datas,Util.JIAJU);
				System.out.println("jiedian111111111"+jiedian);
			}
		
		
	}
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
    private void sendMsgToService(int datas[],int what){
			if(MainZigBeeService.myHandler!=null){
//				if(a){
					Message msg = Message.obtain();
					msg.what = what;
					msg.obj = datas;
					MainZigBeeService.myHandler.sendMessage(msg);
//                    showMsg(anniu);
                   
//				}else{
//					showMsg("�޷���ȡ������ư�����ڵ�ַ���������ڸð�δ����");
//				}
			}else{
				showMsg("����δ��������������û���豸����");
			}
	}
    public void showMsg(String text){
 		Toast.makeText(this, text,200).show();
 	}
}
