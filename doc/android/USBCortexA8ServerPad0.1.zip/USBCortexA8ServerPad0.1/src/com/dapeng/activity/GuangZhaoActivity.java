package com.dapeng.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.dapeng.R;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.AChartView;
import com.dapeng.util.NowTime;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;

@SuppressLint("HandlerLeak")
public class GuangZhaoActivity extends Activity implements OnClickListener{
	ListView gzListView;//�����б�
	SimpleAdapter sAdapter;//�����б�������
	//���ڵ�ַ  �����  �ŵ�  �͹���ǿ����ʾ
	TextView addressTv,netNumTv,singleTv,gzTv;
	ImageView gzIv;
	Button back,lookData;
	LinearLayout guangZhaoLinell;
	//����ͼ����
	AChartView acd;
	int currtIntGuangZhao =0 ;
	float guzhaofloat = 8f;
	
	public static final int GETLRTB = 0;//�¶����ӵ�ĳ�ʼֵ
	public static final int INIT = 1;//��ʼ
	public static final int ADD = 2;//����
	public static final int MINU = 3;//����
	boolean isShow = true,isLanYa_gd=false;
	String strGd[] = {"0x001583004E08","0x001583004DB9","0x001583004DB7","0x001583004DA8","0x001583004DB2","0x001583004DD7","0x001583004E20","0x001583004975","0x00158300493C","0x001583004D9B",
			          "0x001583004982","0x001583004DBC","0x001583004E1A","0x001583004DC2","0x001583004DEB","0x001583004E16","0x001583004DBC","0x00158300493B","0x001583004DC5","0x001583004E05"};
	Handler myHandler = new Handler(){//���պ�̨��������
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.FDDATA:
				isLanYa_gd=true;
				parseData(msg.obj.toString());
				//isLanYa_gd=false;
				break;
			
			}
		}
	};
	
	//������������
	private void parseData(String dataStr){
		 try {
			 String msg[]= dataStr.split(" ");
			 byte data[] = HexDump.hexStringToByteArray(msg[5]+msg[6]);
			//�п��ܻ���ֳ���128������  �ڴ˻��Ϊ���� ��Ҫת��Ϊ0-256֮�������
			int numInt[] = new int[2];
			numInt[0] = data[0];
			numInt[1] = data[1];
			if(data[0]<0){
				numInt[0] = 256+data[1];
			}
			if(data[1]<0){
				numInt[1] = 256+data[1];
			}
			 int gz = numInt[0]*256+numInt[1];
			 acd.updateChart(gz);
			 getDataShowList(gz);
			 gzTv.setText("��ǰ�նȣ�"+gz+" lux");
			 startChangeWd(gz);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	ArrayList<HashMap<String,String>> data = new ArrayList<HashMap<String,String>>(); 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_guangzhao);
		back = (Button)this.findViewById(R.id.guangzhao_back);
		back.setOnClickListener(this);
		gzIv = (ImageView)this.findViewById(R.id.guangzhao_imageView);
		gzTv = (TextView)this.findViewById(R.id.guangzhao_textView);
		gzListView = (ListView)this.findViewById(R.id.guangzhao_listView1);
		guangZhaoLinell = (LinearLayout)this.findViewById(R.id.guangzhao_line_ll);
		
		gzTv.setText("��ǰ�նȣ�0 lux");
		//������������������
		String from[] = {"left","right"};
		int to[] = {R.id.item_textView1,R.id.item_textView2};
		sAdapter = new SimpleAdapter(this, data, R.layout.list_item, from, to);
		gzListView.setAdapter(sAdapter);
		currtIntGuangZhao = Math.round(guzhaofloat);
		//��ʼ������ͼ
		acd = new AChartView(this,guangZhaoLinell,"���ն�����ͼ","ʱ�� S","�ն� lux",0,300,0,1500);
		acd.updateChart(0);
		super.onCreate(savedInstanceState);
		
        lookData = (Button)this.findViewById(R.id.main_lookdata_btn);
        lookData.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent =new Intent(GuangZhaoActivity.this,DataShowActivity.class);
				startActivity(intent);

			}
		});    
	}
	@Override
    protected void onResume() {
    	//����Ϊ��activity��handler
		Util.uiHandler = myHandler;
        Util.whichBlock = "02";//���հ��ӽڵ�
        isShow = true;
    	super.onResume();
    }
	
	@Override
	protected void onPause() {
		isShow = false;
		super.onPause();
	}
	
	private void startChangeWd(int zd){//����0 1 2 3 �����ַ�ʽ�����¶ȼ�
		if(zd==0){
			gzIv.setImageResource(R.drawable.gz_bg12);
		}else if(zd>0&&zd<20){
			gzIv.setImageResource(R.drawable.gz_bg11);
		}else if(zd>=20&&zd<60){
			gzIv.setImageResource(R.drawable.gz_bg10);
		}else if(zd>=60&&zd<100){
			gzIv.setImageResource(R.drawable.gz_bg9);
		}else if(zd>=100&&zd<180){
			gzIv.setImageResource(R.drawable.gz_bg8);
		}else if(zd>=180&&zd<250){
			gzIv.setImageResource(R.drawable.gz_bg7);
		}else if(zd>=250&&zd<350){
			gzIv.setImageResource(R.drawable.gz_bg6);
		}else if(zd>=350&&zd<480){
			gzIv.setImageResource(R.drawable.gz_bg5);
		}else if(zd>=480&&zd<600){
			gzIv.setImageResource(R.drawable.gz_bg4);
		}else if(zd>=600&&zd<700){
			gzIv.setImageResource(R.drawable.gz_bg3);
		}else if(zd>=700&&zd<800){
			gzIv.setImageResource(R.drawable.gz_bg2);
		}else if(zd>=800&&zd<900){
			gzIv.setImageResource(R.drawable.gz_bg1);
		}else if(zd>=900&&zd<1000){
			gzIv.setImageResource(R.drawable.gz_bg0);
		}else{
			gzIv.setImageResource(R.drawable.gz_bg0);
		}
	}
	
	//���list������
	private void getDataShowList(float zhaodu){
		HashMap<String,String> hmdata = new HashMap<String, String>();
		hmdata.put("left", NowTime.getNowTime());
		hmdata.put("right", zhaodu+"");
		data.add(hmdata);
		sAdapter.notifyDataSetChanged();
		gzListView.setSelection(data.size());
	}
	@Override
	public void onClick(View v) {
		isShow = false;
		this.finish();
	}
	
}
