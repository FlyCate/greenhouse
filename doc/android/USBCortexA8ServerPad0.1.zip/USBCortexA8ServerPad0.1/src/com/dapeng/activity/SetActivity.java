package com.dapeng.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo.State;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.service.MainWifiService;
import com.dapeng.service.MainZigBeeService;
import com.hoho.android.usbserial.driver.UsbSerialDriver;

@SuppressLint("NewApi")
public class SetActivity extends Activity implements OnClickListener{
	Button zigbeeBt,blueBt,jinru,back;
	String tag = "";
	public static final String CGQ="cgq";//������
	public static final String GPS="gps";//GPS
	public static final String ONEDESIGN="one";//�������1
	public static final String TWODESIGN="two";//�������2
	public static final String WLTP="wltp";//��������
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setpage);
		jinru = (Button)findViewById(R.id.setpage_jinru_btn);
		back = (Button)findViewById(R.id.setpage_back_btn);
		zigbeeBt = (Button)findViewById(R.id.set_xx_zigbee_btn);
		blueBt = (Button)findViewById(R.id.set_xx_bluetooth_btn);
		blueBt.setOnClickListener(this);
		zigbeeBt.setOnClickListener(this);
		jinru.setOnClickListener(this);
		back.setOnClickListener(this);
		Intent intent = this.getIntent();
		if(intent.hasExtra("tag")){
			tag = (String)intent.getCharSequenceExtra("tag");
		}
		
		final Intent service = new Intent(this, MainZigBeeService.class);
		stopService(service);
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.set_xx_zigbee_btn:
			new DialogSet(this, "ZigBee����");
			break;
		case R.id.set_xx_bluetooth_btn:
			new DialogSet(this, "��������");
			break;
		case R.id.setpage_jinru_btn:
			changeActivity(tag);
			break;
		case R.id.setpage_back_btn:
			this.finish();
			break;
		}
	}
	private void changeActivity(String tag){
		Intent activityIntent =null; 
		if(tag.equals(CGQ)){
//			activityIntent = new Intent(this, ChuanGanQiActivity.class);
			activityIntent = new Intent(this, StartActivity2.class);
		}else  if(tag.equals(WLTP))
		{
			activityIntent = new Intent(this, WltpActivity.class);
		}
		if(activityIntent!=null){
			this.startActivity(activityIntent);
			//ͬʱ��������
			if(driver!=null){
				MainZigBeeService.sDriver = driver;
				final Intent service = new Intent(this, MainZigBeeService.class);
				startService(service);
			} 
//			else{
//				//�ڴ��ж���û��wifi
//				ConnectivityManager manager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
//				//��ȡ״̬
//				State wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
//				//�ж�wifi�����ӵ�����
//				if(wifi == State.CONNECTED||wifi==State.CONNECTING){
//					final Intent service = new Intent(this, MainWifiService.class);
//					startService(service);
//				}else{
//					showMsg("zigbeeģ���wifiģ��û�����ӣ����飡��");
//				}
//			}
			this.finish();
		}
	}
	
	static UsbSerialDriver driver;//�������������Ǵ���
	public static void show(Context context, UsbSerialDriver _driver,String tag) {
		driver = _driver;
        final Intent intent = new Intent(context, SetActivity.class);
        intent.putExtra("tag", tag);
		intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        context.startActivity(intent);
    }
	
	public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
}
