
package com.dapeng.activity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.dapeng.R;
import com.dapeng.R.id;

import com.dapeng.service.GuangZhaoService;
import com.dapeng.service.ShiDuService;
import com.dapeng.service.TuRangSDService;
import com.dapeng.service.WenDuService;
import com.dapeng.util.Util;



@SuppressLint("HandlerLeak")
public class AutoActivity extends Activity implements OnClickListener{
	private Button autochuanglian,autodengguang;
	TextView  failShowTv;
	LinearLayout clLL,dgLL;
	private EditText gzMinEt,gzMaxEt,trsdMinEt,trsdMaxEt,wdMinEt,wdMaxEt,sdMinEt,sdMaxEt;
	
	Button gzBt,trsdBt,wdBt,sdBt;
	int gzNum = 0,trsdNum = 0,wdNum = 0,sdNum = 0;
    Handler myHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.ALLDATA:
				
				break;
//			case Util.SERVICEDOWNTHREADSTOP://��̨�߳�ֹͣ  ֪ͨ�û����������߳�
//				failShowTv.setText(Util.NOSERVERRESTR);
//				failShowTv.setVisibility(View.VISIBLE);
//				break;
//			case Util.NONETWORK://��̨�߳�ֹͣ  ֪ͨ�û����������߳�
//				failShowTv.setText(Util.NONETWORKSTR);
//				failShowTv.setVisibility(View.VISIBLE);
//				break;
			case Util.FDDATA:
				System.out.println((String)msg.obj);
				break;
			case Util.NETADRR:
//				addressTv.setText("���ڵ�ַ��"+msg.obj);
				break;
			case Util.NETNUM:
//				netNumTv.setText("����ţ�"+msg.obj);
				break;
			case Util.SINGLENUM:
//				singleTv.setText("�ŵ��ţ�"+msg.obj);
				break;
			}
		}
	};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autokongzhi);
        gzMinEt = (EditText) findViewById(id.auto_gz_minet);
        gzMaxEt = (EditText) findViewById(id.auto_gz_maxet);
        trsdMinEt = (EditText) findViewById(id.auto_trsd_minet);
        trsdMaxEt = (EditText) findViewById(id.auto_trsd_maxet);
        wdMinEt = (EditText) findViewById(id.auto_wd_minet);
        wdMaxEt = (EditText) findViewById(id.auto_wd_maxet);
        sdMinEt = (EditText) findViewById(id.auto_sd_minet);
        sdMaxEt = (EditText) findViewById(id.auto_sd_maxet);
        
       
        gzBt = (Button) findViewById(id.auto_gz_bt);
        trsdBt = (Button) findViewById(id.auto_trsd_bt);
        wdBt = (Button) findViewById(id.auto_wd_bt);
        sdBt = (Button) findViewById(id.auto_sd_bt);
        
        gzBt.setOnClickListener(this);
        trsdBt.setOnClickListener(this);
        wdBt.setOnClickListener(this);
        sdBt.setOnClickListener(this);
        
        gzMinEt.setText(GuangZhaoService.gzMin+"");
        gzMaxEt.setText(GuangZhaoService.gzMax+"");
        
        trsdMinEt.setText(TuRangSDService.trsdMin+"");
        trsdMaxEt.setText(TuRangSDService.trsdMax+"");
        
        wdMinEt.setText(WenDuService.wdMin+"");
        wdMaxEt.setText(WenDuService.wdMax+"");
        
        sdMinEt.setText(ShiDuService.sdMin+"");
        sdMaxEt.setText(ShiDuService.sdMax+"");
        
        if(GuangZhaoService.gzService){
        	gzBt.setText("�ѿ������նȿ���");
        }else{
        	gzBt.setText("�ѹرչ��նȿ���");
        }
        
        if(WenDuService.wdService){
        	wdBt.setText("�ѿ��������¶ȿ���");
        }else{
        	wdBt.setText("�ѹرմ����¶ȿ���");
        }
        
        if(ShiDuService.sdService){
        	sdBt.setText("�ѿ�������ʪ�ȿ���");
        }else{
        	sdBt.setText("�ѹرմ���ʪ�ȿ���");
        }
        
        if(TuRangSDService.trsdService){
        	trsdBt.setText("�ѿ�������ʪ�ȿ���");
        }else{
        	trsdBt.setText("�ѹر�����ʪ�ȿ���");
        }
    }
    
    @Override
    protected void onResume() {
    	//����Ϊ��activity��handler
    	Util.uiHandler = myHandler;
    	super.onResume();
    }
    @Override
	protected void onStop() {
//		Util.unBindMyService(this);
		super.onStop();
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.auto_gz_bt:
			if(gzMinEt.getText()==null){
				GuangZhaoService.gzMin = -1;
				
			}else {
				GuangZhaoService.gzMin = Integer.parseInt(gzMinEt.getText().toString());
			}
			
            if(gzMaxEt.getText()==null){
            	GuangZhaoService.gzMax = -1;
			}else {
				GuangZhaoService.gzMax = Integer.parseInt(gzMaxEt.getText().toString());
			}
            if(GuangZhaoService.gzMin!=-1 && GuangZhaoService.gzMax!=-1 ){
            	if(GuangZhaoService.gzService==false){
            		gzBt.setText("�ѿ������նȿ���");
            		Intent intent = new Intent(this,GuangZhaoService.class);
            		startService(intent);
//            		gzNum = 1;
            		GuangZhaoService.gzService = true;
            	}else if(GuangZhaoService.gzService){
            		GuangZhaoService.stopTimer();
            		gzBt.setText("�ѹرչ��նȿ���");
            		Intent intent = new Intent(this,GuangZhaoService.class);
            		stopService(intent);
//            		gzNum = 0;
            		GuangZhaoService.gzService = false;
            		
            	}
            }else{
            	showMsg("�����ù��նȵķ�Χ��");
            }
			break;
		case R.id.auto_trsd_bt:
			 if(trsdMinEt.getText()==null){
	            	TuRangSDService.trsdMin = -1;
				}else {
					TuRangSDService.trsdMin = Integer.parseInt(trsdMinEt.getText().toString());
				}
	            if(trsdMaxEt.getText()==null){
	            	TuRangSDService.trsdMax = -1;
	 			}else {
	 				TuRangSDService.trsdMax = Integer.parseInt(trsdMaxEt.getText().toString());
	 			} 
	            
	            if(TuRangSDService.trsdMin!=-1 && TuRangSDService.trsdMax!=-1 ){
	            	if(TuRangSDService.trsdService ==false){
	            		trsdBt.setText("�ѿ������նȿ���");
	            		Intent intent = new Intent(this,TuRangSDService.class);
	            		startService(intent);
//	            		trsdNum = 1;
	            		TuRangSDService.trsdService = true;
	            	}else if(TuRangSDService.trsdService){
	            		TuRangSDService.stopTimer();
	            		trsdBt.setText("�ѹرչ��նȿ���");
	            		Intent intent = new Intent(this,TuRangSDService.class);
	            		stopService(intent);
//	            		trsdNum = 0;
	            		TuRangSDService.trsdService = false;
	            		
	            	}
	            }else{
	            	showMsg("����������ʪ�ȵķ�Χ��");
	            }
			break;
		case R.id.auto_wd_bt:
            if(wdMinEt.getText()==null){
            	WenDuService.wdMin = -1;
			}else {
				WenDuService.wdMin = Integer.parseInt(wdMinEt.getText().toString());
			}
            if(wdMaxEt.getText()==null){
            	WenDuService.wdMax = -1;
 			}else {
 				WenDuService.wdMax = Integer.parseInt(wdMaxEt.getText().toString());
 			} 
            
            if(WenDuService.wdMin!=-1 && WenDuService.wdMax!=-1 ){
            	if(WenDuService.wdService == false){
            		wdBt.setText("�ѿ������նȿ���");
            		Intent intent = new Intent(this,WenDuService.class);
            		startService(intent);
//            		wdNum = 1;
            		WenDuService.wdService = true;
            	}else if(WenDuService.wdService){
            		WenDuService.stopTimer();
            		wdBt.setText("�ѹرչ��նȿ���");
            		Intent intent = new Intent(this,WenDuService.class);
            		stopService(intent);
//            		wdNum = 0;
            		WenDuService.wdService = false;
            		
            	}
            }else{
            	showMsg("�������¶ȵķ�Χ��");
            }
			break;
		case R.id.auto_sd_bt:
			 if(sdMinEt.getText()==null){
	            	ShiDuService.sdMin = -1;
				}else {
					ShiDuService.sdMin = Integer.parseInt(sdMinEt.getText().toString());
				}
	            if(sdMaxEt.getText()==null){
	            	ShiDuService.sdMax = -1;
	 			}else {
	 				ShiDuService.sdMax = Integer.parseInt(sdMaxEt.getText().toString());
	 			} 
	            
	            if(ShiDuService.sdMin!=-1 && ShiDuService.sdMax!=-1 ){
	            	if(ShiDuService.sdService == false){
	            		sdBt.setText("�ѿ������նȿ���");
	            		Intent intent = new Intent(this,ShiDuService.class);
	            		startService(intent);
//	            		sdNum = 1;
	            		ShiDuService.sdService = true;
	            	}else if(ShiDuService.sdService ){
	            		ShiDuService.stopTimer();
	            		sdBt.setText("�ѹرչ��նȿ���");
	            		Intent intent = new Intent(this,ShiDuService.class);
	            		stopService(intent);
//	            		sdNum = 0;
	            		ShiDuService.sdService = false;
	            		
	            	}
	            }else{
	            	showMsg("������ʪ�ȵķ�Χ��");
	            }
			break;
		}
	}	
	public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
}
