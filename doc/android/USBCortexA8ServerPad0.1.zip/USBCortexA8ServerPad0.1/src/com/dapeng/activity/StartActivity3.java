package com.dapeng.activity;

import com.dapeng.R;
import com.dapeng.R.id;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class StartActivity3 extends Activity implements OnClickListener{
    ImageView ganzhiIV,anfangIV,baojingIV,shexiangjiIV;
    Button shefangBt,chefangBt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_start3);
		ganzhiIV = (ImageView) findViewById(id.start3_ganzhi);
		anfangIV = (ImageView) findViewById(id.start3_anfang);
		baojingIV = (ImageView) findViewById(id.start3_baojing);
		shexiangjiIV = (ImageView) findViewById(id.start3_shexiangji);
		shefangBt = (Button) findViewById(id.start3_shefangBt);
		chefangBt = (Button) findViewById(id.start3_chefangBt);		
		
		ganzhiIV.setOnClickListener(this);
		anfangIV.setOnClickListener(this);
		baojingIV.setOnClickListener(this);
		shexiangjiIV.setOnClickListener(this);
		shefangBt.setOnClickListener(this);
		chefangBt.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.start3_ganzhi://��֪
			changeActivity(JianKongActivity.class,"");
			break;
		case R.id.start3_baojing://������Ϣ
			break;
		case R.id.start3_shexiangji://�����
			break;
		case R.id.start3_shefangBt:
		    break;
		case R.id.start3_chefangBt:
			break;
		}
	}
	//������ת
	private void changeActivity(@SuppressWarnings("rawtypes") Class cls,String data){
		Intent intent = new Intent(this, cls);
		intent.putExtra("form", data);
		intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		this.startActivity(intent);
	}
	
}
