package com.dapeng.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import android.R.id;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.dapeng.R;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.AChartView;
import com.dapeng.util.NowTime;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;

public class WenDuActivity extends Activity implements OnClickListener{
	ListView wenDuListView;
	TextView addressTv,netNumTv,singleTv,wenDuTv,title;;
	FrameLayout wenduAddFL;
	LinearLayout wenduLinell;
	ImageView wenDuIv;
	Button back;
	//list������
	SimpleAdapter sAdapter;
	//����ͼ����
	AChartView acd;
	int left,right,top,bottom;
	int count = 0;//��������ǰ���β�ƽ�ȵ��¶�ֵ
	double wendu = -100.0;
	double currtDoubleWenDu =0 ;
	boolean isLanYa_wd=false;
	String name;
	double trsd = 0.0;
	public static final int GETLRTB = 0;//�¶����ӵ�ĳ�ʼֵ
	public static final int INIT = 1;//��ʼ
	public static final int ADD = 2;//����
	public static final int MINU = 3;//����
	String strWd[] = {"0x001583004DC9","0x001583004DD1","0x001583004DAA","0x001583004DFF","0x0015830049B3","0x0015830047E5","0x001583004DB4","0x001583004DF1","0x001583004DF4","0x001583004DF6",
			          "0x001583004D9E","0x001583004E0C","0x001583004DC7","0x001583004DB9","0x001583004DED","0x001583004B7E","0x001583004973","0x001583004E17","0x001583004953","0x0015830047DE"};
	@SuppressLint("HandlerLeak")
	Handler wdHandler = new Handler(){//�����¶ȼ�
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case GETLRTB://�¶����ӵ�ĳ�ʼֵ
				left = wenduAddFL.getLeft();
				right = wenduAddFL.getRight();
				top = wenduAddFL.getTop();
				bottom = wenduAddFL.getBottom();
				break;
			case INIT://��ʼ
				if(top-msg.arg1*0.25>33){
					wenduAddFL.layout(left, (int)(Math.round(top-msg.arg1*0.25)), right,bottom);
				}
				break;
			case ADD://����
				if(top-msg.arg1*0.25>33){
					wenduAddFL.layout(left, (int)(Math.round(top-msg.arg1*0.25)), right,bottom);
				}
				break;
			}
		};
	};
	@SuppressLint("HandlerLeak")
	Handler myHandler = new Handler(){//���պ�̨��������
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.FDDATA:	
				String data[] = ((String)msg.obj).split(" ");
				if(data[4].equals("09")){
					parseWenDu((String)msg.obj);	
				}else if(data[4].equals("B1")){
					parseTuRang(data);
				}
							
				break;
			case Util.NETADRR:
				//addressTv.setText("���ڵ�ַ��"+msg.obj);
				
				break;
			case Util.NETNUM:
				//netNumTv.setText("����ţ�"+msg.obj);
				break;
			case Util.SINGLENUM:
				//singleTv.setText("�ŵ��ţ�"+msg.obj);
				break;
			}
		}
	};
	private void parseTuRang(String strs[]){
		byte shiduByte[] = HexDump.hexStringToByteArray(strs[7]+strs[8]);
		trsd =  Double.parseDouble(shiduByte[0]+"."+shiduByte[1]);
	}
	//�������ͼ����
	ArrayList<HashMap<String,String>> data = new ArrayList<HashMap<String,String>>(); 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_wendu);
		back = (Button)this.findViewById(R.id.wendu_back);
		back.setOnClickListener(this);
		wenduAddFL = (FrameLayout)this.findViewById(R.id.wendu_add_fl);
		wenduLinell = (LinearLayout)this.findViewById(R.id.wendu_line_ll);
		wenDuIv = (ImageView)this.findViewById(R.id.wendu_imageView);
		wenDuTv = (TextView)this.findViewById(R.id.wendu_textView);
		//addressTv = (TextView)this.findViewById(R.id.wendu_addr_tv);
		//netNumTv = (TextView)this.findViewById(R.id.wendu_netNum_tv);
		//singleTv = (TextView)this.findViewById(R.id.wendu_singelNum_tv);
		wenDuListView = (ListView)this.findViewById(R.id.wendu_listView1);
		wenDuTv.setText("��ǰ�¶ȣ�0.0��");
		title = (TextView) findViewById(R.id.title);
		
		if(this.getIntent().hasExtra("form")){
			String name = (String)this.getIntent().getCharSequenceExtra("form");
			title.setText(name);
		}
		String from[] = {"left","right"};
		int to[] = {R.id.item_textView1,R.id.item_textView2};
		sAdapter = new SimpleAdapter(this, data, R.layout.list_item, from, to);
		wenDuListView.setAdapter(sAdapter);
		//��ʼ������ͼ
		acd = new AChartView(this,wenduLinell,"�¶�����ͼ","ʱ�� S","�¶� ��",0,100,-10,50);
		acd.updateChart(0);
		currtDoubleWenDu = 25.0;
		super.onCreate(savedInstanceState);
	}
	@Override
    protected void onResume() {
    	//����Ϊ��activity��handler
		Util.uiHandler = myHandler;
		Util.whichBlock = "showdata";
//		if(this.getIntent().hasExtra("form")){
//			name = (String)this.getIntent().getCharSequenceExtra("form");
//			if(name.equals("�����¶�")){
//				Util.whichBlock = "09";//��ʪ�Ȱ��ӽڵ��ַ
//			}else{
//				Util.whichBlock = "B1";//��ʪ�Ȱ��ӽڵ��ַ
//			}
//		}
        
        
    	super.onResume();
    }
	private void parseWenDu(String dataStr){
		try {
				String datas[] = dataStr.split(" ");
					//�±�Ϊ5�Ķ�Ӧ�����¶ȵ�����λ �±�Ϊ6�Ķ�Ӧ���¶ȵ�С��λ
					byte wenduByte[] = HexDump.hexStringToByteArray(datas[5]+datas[6]);
					String wenduStr = wenduByte[0]+"."+wenduByte[1];
					if(name.equals("�����¶�")){
						if(wendu==-100){//�ж��Ƿ�Ϊ��һ��
							wendu = Double.parseDouble(wenduStr)-20;
							currtDoubleWenDu = wendu+10;
							startChangeWd(INIT,currtDoubleWenDu);
						}else{
							wendu = Double.parseDouble(wenduStr)-20;
							if((wendu+10)-currtDoubleWenDu!=0){
								startChangeWd(ADD,(wendu+10)-currtDoubleWenDu);
								currtDoubleWenDu = wendu+10;
							}
						}
					}else{
						if(trsd!=0.0){
							if(trsd>80){
								if(wendu==-100){//�ж��Ƿ�Ϊ��һ��
									wendu = Double.parseDouble(wenduStr)-26;
									currtDoubleWenDu = wendu+10;
									startChangeWd(INIT,currtDoubleWenDu);
								}else{
									wendu = Double.parseDouble(wenduStr)-26;
									if((wendu+10)-currtDoubleWenDu!=0){
										startChangeWd(ADD,(wendu+10)-currtDoubleWenDu);
										currtDoubleWenDu = wendu+10;
									}
								}
							}else{
								if(wendu==-100){//�ж��Ƿ�Ϊ��һ��
									wendu = Double.parseDouble(wenduStr)-23;
									currtDoubleWenDu = wendu+10;
									startChangeWd(INIT,currtDoubleWenDu);
								}else{
									wendu = Double.parseDouble(wenduStr)-23;
									if((wendu+10)-currtDoubleWenDu!=0){
										startChangeWd(ADD,(wendu+10)-currtDoubleWenDu);
										currtDoubleWenDu = wendu+10;
									}
								}
							}
						}
						
						
					}
					
					//�����ı���Ϣ
					wenDuTv.setText("��ǰ�¶ȣ�"+wendu+"��");
					//��������ͼ
					acd.updateChart(wendu);
					//����list
					getDataShowList(wendu);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void startChangeWd(final int mode,final double addWenDu){//����0 1 2 3 �����ַ�ʽ�����¶ȼ�
			new Thread(){
				public void run(){
					try {
						//����ͬ����ֹͬʱ�̿��������߳�
						synchronized (ACCESSIBILITY_SERVICE) {
							sendMsg(GETLRTB,0);
							if(addWenDu>0){
								//�¶������Ľ�������ͼ����
								for(int i = 1;i<=(int)(addWenDu*10);i++){
									Thread.sleep(10);
									sendMsg(mode,i);
								}
							}else{
								//�¶��½��Ľ�������ͼ����
								for(int i = -1;i>(int)(addWenDu*10);i--){
									Thread.sleep(10);
									sendMsg(mode,i);
								}
							}
						}
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}.start();
	}
	
	public void sendMsg(int what,int arg1){
		Message msg = Message.obtain();
		msg.what = what;
		msg.arg1 = arg1;
		if(wdHandler!=null){
			wdHandler.sendMessage(msg);
		}
	}
	
	//���list������
	private void getDataShowList(double wendu){
		HashMap<String,String> hmdata = new HashMap<String, String>();
		hmdata.put("left", NowTime.getNowTime());
		hmdata.put("right", wendu+"");
		data.add(hmdata);
		sAdapter.notifyDataSetChanged();
		wenDuListView.setSelection(data.size());
	}
	@Override
	public void onClick(View v) {
//		startChangeWd(ADD,3);
		this.finish();
	}
	
}
