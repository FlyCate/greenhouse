
package com.dapeng.activity;

import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;


@SuppressLint("HandlerLeak")
public class JianKongActivity extends Activity implements OnClickListener{
    private TextView titleView;
    ImageView renti_light,renti,zhendong_imageView,menci_imageView,yanwu_imageView2,menjin_imageView,mulian_imageView1,mulian_imageView2;
    Button menjinOpenBt,menjinCloseBt;
    boolean isRenTi = false;
    int addr1 = 0,addr2 = 0;
    int menjin_jiedian = 0;
    Handler myHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.ALLDATA:
				break;
			case Util.FDDATA:
				String msg1[]= msg.obj.toString().split(" ");
				if(msg1[0].equals("FD")){
					if(msg1[4].equals("B1")){//
						
					}else if(msg1[4].equals("B4")){
						
					}
				}else if(msg1[0].equals("55")){
					if(msg1[6].equals("A5")){//�������
						isRenTi = true;
						parseData_renti(msg1);
						
					}else if(msg1[5].equals("7A")){//�Ŵ�
						parseData_menci(msg1);
					}
				}
				break;
			}
		}
	};
	//���������������
	private void parseData_renti(String msg[]){
		renti_light.setBackgroundResource(R.drawable.lighton);
		renti.setBackgroundResource(R.drawable.switchon);
        isRenTi = false;
	}
    //�Ŵ�
	private void parseData_menci(String msg1[]){
		if(msg1[7].equals("09")){//��
			menci_imageView.setImageResource(R.drawable.huoer2);
		}else if(msg1[7].equals("08")){//��
			menci_imageView.setImageResource(R.drawable.huoer1);
		}
	}
	//����
	private void parseData_yanwu(String msg1[]){
		if(msg1[5].equals("4E")){//��
			yanwu_imageView2.setImageResource(R.drawable.lighton);
		}else if(msg1[5].equals("46")){//��
			yanwu_imageView2.setImageResource(R.drawable.lightoff);
		}
	}
    //�Ž�
    private void parseData_menjin(String msg[]){
    	 byte data[] = HexDump.hexStringToByteArray(msg[17]+msg[18]);
    	addr1 = data[0];
    	addr2 = data[1];
		if(msg[5].equals("4E")){//��
			menjin_imageView.setImageResource(R.drawable.lock_on);
		}else if(msg[5].equals("46")){//��
			menjin_imageView.setImageResource(R.drawable.lock_off);
		}
	}
    //����Ļ��������
    private void parseData_mulian(String msg[]){
		if(msg[5].equals("4E")){//��
			mulian_imageView1.setBackgroundResource(R.drawable.lighton);
			mulian_imageView2.setBackgroundResource(R.drawable.switchon);
		}else if(msg[5].equals("46")){//��
			mulian_imageView1.setBackgroundResource(R.drawable.lightoff);
			mulian_imageView2.setBackgroundResource(R.drawable.switchoff);
		}
	}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jiankong);
        renti_light = (ImageView)findViewById(R.id.renti_imageView);
        renti = (ImageView)findViewById(R.id.renti_imageView2);
        menci_imageView = (ImageView) findViewById(R.id.jiankong_menciIV);
        yanwu_imageView2 = (ImageView) findViewById(id.jiankong_yanwuIV2);
        menjin_imageView = (ImageView) findViewById(id.jiankong_menciIV);
        mulian_imageView1 = (ImageView) findViewById(id.jiankong_mulianIV1);
        mulian_imageView2 = (ImageView) findViewById(id.jiankong_mulianIV2);
        menjinOpenBt = (Button) findViewById(id.jiankong_nenjinBtOpen);
        menjinCloseBt = (Button) findViewById(id.jiankong_nenjinBtClose);
        menjinOpenBt.setOnClickListener(this);
        menjinCloseBt.setOnClickListener(this);
        timer_renti.schedule(task_renti, 3000, 3000);

        

    }
    Handler handler_renti = new Handler() {  
	   	  public void handleMessage(Message msg) {  
	   	       if(msg.what==0){
	   	    	renti_light.setBackgroundResource(R.drawable.lightoff);
				renti.setBackgroundResource(R.drawable.switchoff);

	   	       }  
	   	       super.handleMessage(msg);  
	   	  };  
	     };  
	    
	Timer timer_renti = new Timer();  
	TimerTask task_renti = new TimerTask() {  
	   	  
	   	  @Override  
	   	   public void run() {  
	   	            // ��Ҫ������:������Ϣ   
	   	      Message message = new Message();   
	   		  if(isRenTi){
	   			  message.what = 1;  
	   		  }else{
	   			  message.what = 0;  
	   		  }
	   		  handler_renti.sendMessage(message);  
	   	    }  
	   	
	   };

    @Override
    protected void onResume() {
    	//����Ϊ��activity��handler
    	Util.uiHandler = myHandler;
    	Util.whichBlock = "showdata";
    	super.onResume();
    }

	@Override
	public void onClick(View v) {
	    switch(v.getId()){
	    case R.id.jiankong_nenjinBtOpen:
	    	int datas4[] = {addr1,addr2,menjin_jiedian,0x4E,0xAA,0xAA,0xAA};
			sendMsgToService(datas4,Util.DSONE5OPEN);
	    	break;
	    case R.id.jiankong_nenjinBtClose:
	    	int datas5[] = {addr1,addr2,menjin_jiedian,0x46,0xAA,0xAA,0xAA};
			sendMsgToService(datas5,Util.DSONE5OPEN);
	    	break;
	    }
		
	}
	private void sendMsgToService(int datas[],int what){
		  if(MainZigBeeService.myHandler!=null){
			if(Util.addr1!=0||Util.addr2!=0){
				Message msg = Message.obtain();
				msg.what = what;
				msg.obj = datas;
				MainZigBeeService.myHandler.sendMessage(msg);
			}else{
				showMsg("�޷���ȡ������ư�����ڵ�ַ���������ڸð�δ����");
					}			
		  }else{
			showMsg("����δ��������������û���豸����");
		  }
		}
	//������ת
	private void changeActivity(@SuppressWarnings("rawtypes") Class cls,String data){
		Intent intent = new Intent(this, cls);
		intent.putExtra("form", data);
		intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		this.startActivity(intent);
	}
	
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
    
}
