package com.dapeng.activity;



import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class JiaDianActivity extends Activity implements OnClickListener{
    ImageView fengshanImg;
    int jiedian = 0x07,jiedian1 = 0x08,jiedian2 = 0x0A,jiedian3 = 0x09;
    Button shuibeng_openBt,shuibeng_closeBt,rebeng_openBt1,rebeng_closeBt1,rebeng_openBt2,rebeng_closeBt2,shuilian_openBt,shuilian_closeBt,tianchuang_openBt,tianchuang_closeBt,
    tianchuang_stopBt,zheyangzhao_openBt,zheyangzhao_closeBt,zheyangzhao_stopBt,baowenlian_openBt,baowenlian_closeBt,baowenlian_stopBt;
    Handler myHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.ALLDATA:
				break;
			case Util.FDDATA:
				String msg1[]= msg.obj.toString().split(" ");
			    if(msg1[4].equals("A8")){
			    	parseData_san(msg1);
			    }else if(msg1[4].equals("A1")){
			    	System.out.println("�촰���ݡ�����="+msg.obj.toString());
			    	parseData_tianchuang(msg1);
			    }else if(msg1[4].equals("A2")){
			    	parseData_zheyangzhao(msg1);
			    }else if(msg1[4].equals("A3")){
			    	parseData_banwenlian(msg1);
			    }
				break;
			}
		}
	};
	private void parseData_san(String msg[]){
		//if(msg[5]){}
	}
	private void parseData_tianchuang(String msg[]){
		
	}
	private void parseData_zheyangzhao(String msg[]){
		
	}
	private void parseData_banwenlian(String msg[]){
		
	}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_jiadian);
    	shuibeng_openBt = (Button) findViewById(id.shuibeng_openbt);
    	shuibeng_closeBt = (Button) findViewById(id.shuibeng_closebt);
    	rebeng_openBt1 = (Button) findViewById(id.rebeng_openbt1);
    	rebeng_closeBt1 = (Button) findViewById(id.rebeng_closebt1);
    	rebeng_openBt2 = (Button) findViewById(id.rebeng_openbt2);
    	rebeng_closeBt2 = (Button) findViewById(id.rebeng_closebt2);
    	shuilian_openBt = (Button) findViewById(id.shuilian_openbt);
    	shuilian_closeBt = (Button) findViewById(id.shuilian_closebt);
    	tianchuang_openBt = (Button) findViewById(id.tianchuang_openbt);
    	tianchuang_closeBt = (Button) findViewById(id.tianchuang_closebt);
    	tianchuang_stopBt = (Button) findViewById(id.tianchuang_stopbt);
        zheyangzhao_openBt = (Button) findViewById(id.zheyangzhao_openbt);
        zheyangzhao_closeBt = (Button) findViewById(id.zheyangzhao_closebt);
        zheyangzhao_stopBt = (Button) findViewById(id.zheyangzhao_stopbt);
        baowenlian_openBt = (Button) findViewById(id.baowenlian_openbt);
        baowenlian_closeBt = (Button) findViewById(id.baowenlian_closebt);
        baowenlian_stopBt = (Button) findViewById(id.baowenlian_stopbt);
        
        shuibeng_openBt.setOnClickListener(this);
    	shuibeng_closeBt.setOnClickListener(this);
    	rebeng_openBt1.setOnClickListener(this);
    	rebeng_closeBt1.setOnClickListener(this);
    	rebeng_openBt2.setOnClickListener(this);
    	rebeng_closeBt2.setOnClickListener(this);
    	shuilian_openBt.setOnClickListener(this);
    	shuilian_closeBt.setOnClickListener(this);
    	tianchuang_openBt.setOnClickListener(this);
    	tianchuang_closeBt.setOnClickListener(this);
    	tianchuang_stopBt.setOnClickListener(this);
        zheyangzhao_openBt.setOnClickListener(this);
        zheyangzhao_closeBt.setOnClickListener(this);
        zheyangzhao_stopBt.setOnClickListener(this);
        baowenlian_openBt.setOnClickListener(this);
        baowenlian_closeBt.setOnClickListener(this);
        baowenlian_stopBt.setOnClickListener(this);
    }
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
//		MainZigBeeService.typeNum = 1;
		MainZigBeeService.stopTimer();
		switch(v.getId()){
		case R.id.rebeng_openbt1:
			int datas2[] = {jiedian,0x0A,0x4B,0x4E,0xAA,0xAA,0xAA};
			sendMsgToService(datas2,Util.DSONE5OPEN);
			break;
		case R.id.rebeng_closebt1:
			int datas3[] = {jiedian,0x0A,0x4B,0x46,0xAA,0xAA,0xAA};
			sendMsgToService(datas3,Util.DSONE5OPEN);
			break;
		case R.id.rebeng_openbt2:
			int datas15[] = {jiedian,0x0A,0x4B,0xAA,0x4E,0xAA,0xAA};
			sendMsgToService(datas15,Util.DSONE5OPEN);
			break;
		case R.id.rebeng_closebt2:
			int datas16[] = {jiedian,0x0A,0x4B,0xAA,0x46,0xAA,0xAA};
			sendMsgToService(datas16,Util.DSONE5OPEN);
			break;
		case R.id.shuibeng_openbt:
			int datas[] = {jiedian,0x0A,0x4B,0xAA,0xAA,0x4E,0xAA};
			sendMsgToService(datas,Util.DSONE5OPEN);
			break;
		case R.id.shuibeng_closebt:
			int datas1[] = {jiedian,0x0A,0x4B,0xAA,0xAA,0x46,0xAA};
			sendMsgToService(datas1,Util.DSONE5OPEN);
			break;		
		case R.id.shuilian_openbt:
			int datas4[] = {jiedian,0x0A,0x4B,0xAA,0xAA,0xAA,0x4E};
			sendMsgToService(datas4,Util.DSONE5OPEN);
			break;
		case R.id.shuilian_closebt:
			int datas5[] = {jiedian,0x0A,0x4B,0xAA,0xAA,0xAA,0x46};
			sendMsgToService(datas5,Util.DSONE5OPEN);
			break;
		case R.id.tianchuang_openbt:
			int datas6[] = {jiedian1,0x0A,0x4B,0x4F,0xAA,0xAA,0xAA};
			sendMsgToService(datas6,Util.DSONE5OPEN);
			break;
		case R.id.tianchuang_closebt:
			int datas7[] = {jiedian1,0x0A,0x4B,0x43,0xAA,0xAA,0xAA};
			sendMsgToService(datas7,Util.DSONE5OPEN);
			break;
		case R.id.tianchuang_stopbt:
			int datas8[] = {jiedian1,0x0A,0x4B,0x53,0xAA,0xAA,0xAA};
			sendMsgToService(datas8,Util.DSONE5OPEN);
			break;
		case R.id.zheyangzhao_openbt:
			int datas9[] = {jiedian2,0x0A,0x4B,0x4F,0xAA,0xAA,0xAA};
			sendMsgToService(datas9,Util.DSONE5OPEN);
			break;
		case R.id.zheyangzhao_closebt:
			int datas10[] = {jiedian2,0x0A,0x4B,0x43,0xAA,0xAA,0xAA};
			sendMsgToService(datas10,Util.DSONE5OPEN);
			break;
		case R.id.zheyangzhao_stopbt:
			int datas11[] = {jiedian2,0x0A,0x4B,0x53,0xAA,0x46,0xAA};
			sendMsgToService(datas11,Util.DSONE5OPEN);
			break;
		case R.id.baowenlian_openbt:
			int datas12[] = {jiedian3,0x0A,0x4B,0x4F,0xAA,0xAA,0xAA};
			sendMsgToService(datas12,Util.DSONE5OPEN);
			break;
		case R.id.baowenlian_closebt:
			int datas13[] = {jiedian3,0x0A,0x4B,0x43,0xAA,0xAA,0xAA};
			sendMsgToService(datas13,Util.DSONE5OPEN);
			break;
		case R.id.baowenlian_stopbt:
			int datas14[] = {jiedian3,0x0A,0x4B,0x53,0xAA,0xAA,0xAA};
			sendMsgToService(datas14,Util.DSONE5OPEN);
			break;
		}
//		MainZigBeeService.typeNum = 0;
	}
	
   protected void onResume() {
	    	//����Ϊ��activity��handler
	    	Util.uiHandler = myHandler;
	    	Util.whichBlock = "showdata";
	    	super.onResume();
   }
   private void sendMsgToService(int datas[],int what){
	   if(MainZigBeeService.myHandler!=null){
						Message msg = Message.obtain();
						msg.what = what;
						msg.obj = datas;
						MainZigBeeService.myHandler.sendMessage(msg);
		}else{
			showMsg("����δ��������������û���豸����");
		}
	} 
   public void showMsg(String text){
		Toast.makeText(this, text,200).show();
	}
}
