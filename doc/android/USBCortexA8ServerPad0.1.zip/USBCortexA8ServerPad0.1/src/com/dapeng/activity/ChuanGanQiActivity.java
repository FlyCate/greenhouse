
package com.dapeng.activity;

import android.R.id;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.util.Util;


@SuppressLint("HandlerLeak")
public class ChuanGanQiActivity extends Activity implements OnClickListener{
	
    private ImageView wenduIv,guangzhaoIv,shiduIv,co2Iv,turangWDTv,turangSDTv,fengsuIv;
    private Button lookData,back;
    
    Handler myHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case Util.ALLDATA:
				
				break;
			case Util.FDDATA:
				
				break;
			}
		}
	};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chuanganqi);
        lookData = (Button)this.findViewById(R.id.main_lookdata_btn);
        back = (Button)this.findViewById(R.id.main_back_btn);
        wenduIv = (ImageView)this.findViewById(R.id.wendu_ImageView);
        wenduIv.setOnClickListener(this);
        guangzhaoIv = (ImageView)this.findViewById(R.id.guangzhao_imageView);
        guangzhaoIv.setOnClickListener(this);
        shiduIv = (ImageView)this.findViewById(R.id.shidu_imageView);
        shiduIv.setOnClickListener(this);
        co2Iv = (ImageView)this.findViewById(R.id.co2_imageView);
        co2Iv.setOnClickListener(this);
        turangWDTv = (ImageView)this.findViewById(R.id.turang_wendu_ImageView);
        turangWDTv.setOnClickListener(this);
        turangSDTv = (ImageView)this.findViewById(R.id.turang_shidu_imageView);
        turangSDTv.setOnClickListener(this);
        lookData.setOnClickListener(this);
        back.setOnClickListener(this);
        
        fengsuIv = (ImageView) findViewById(R.id.cgq_fengsu_imageView);
        fengsuIv.setOnClickListener(this);
       
    }
    
    @Override
    protected void onResume() {
    	//����Ϊ��activity��handler
    	Util.uiHandler = myHandler;
    	super.onResume();
    }

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.wendu_ImageView:
			changeActivity(WenDuActivity.class,"�����¶�");
			break;
		case R.id.guangzhao_imageView:
			changeActivity(GuangZhaoActivity.class,"");
			break;
		case R.id.shidu_imageView:
			changeActivity(ShiDuActivity.class,"����ʪ��");
			break;
		case R.id.co2_imageView:
			changeActivity(TRQActivity.class,"");
			break;
		case R.id.turang_wendu_ImageView:
			changeActivity(WenDuActivity.class,"�����¶�");
			break;
		case R.id.turang_shidu_imageView:
			changeActivity(ShiDuActivity.class,"����ʪ��");
			break;
		case R.id.main_lookdata_btn:
			changeActivity(DataShowActivity.class,"");
			break;
		case R.id.cgq_fengsu_imageView:
			changeActivity(FengSuActivity.class,"");
			break;
		case R.id.main_back_btn:
			this.finish();
			break;
		}
		
	}
	
	//������ת
	private void changeActivity(@SuppressWarnings("rawtypes") Class cls,String name){
		Intent intent = new Intent(this, cls);
		intent.putExtra("form", name);
		intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		this.startActivity(intent);
	}
	
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
}
