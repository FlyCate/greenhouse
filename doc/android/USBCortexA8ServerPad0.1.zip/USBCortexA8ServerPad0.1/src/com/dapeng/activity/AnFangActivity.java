package com.dapeng.activity;

import java.util.Timer;
import java.util.TimerTask;

import com.dapeng.R;
import com.dapeng.R.id;
import com.dapeng.service.MainZigBeeService;
import com.dapeng.util.Util;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class AnFangActivity extends Activity implements OnClickListener{
    ImageView hongwaiImg,yanwuImg,zhendongImg,liandongImg,hongwaiImg2,yanwuImg2,zhendongImg2;
    Button hongwaiBt,yanwuBt,zhendongBt,liandongBt;
    Handler myHandler = new Handler(){
  		public void handleMessage(android.os.Message msg) {
  			switch (msg.what) {
  			case Util.ALLDATA:
  				break;
  			case Util.FDDATA:
  				
  			
  				break;
  			}
  		}
  	};
	@Override
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_anfang);
    	hongwaiImg = (ImageView) findViewById(id.hongwai_img);
    	yanwuImg = (ImageView) findViewById(id.yanwu_img);
    	zhendongImg = (ImageView) findViewById(id.zhendong_img);
    	hongwaiImg2 = (ImageView) findViewById(id.hongwai_img2);
    	yanwuImg2 = (ImageView) findViewById(id.yanwu_img2);
    	zhendongImg2 = (ImageView) findViewById(id.zhendong_img2);
//    	liandongImg = (ImageView) findViewById(id.liandong_img);
    	
//    	hongwaiBt = (Button) findViewById(id.hongwai_bt);
//    	yanwuBt = (Button) findViewById(id.yanwu_bt);
//    	zhendongBt = (Button) findViewById(id.zhendong_bt);
//    	liandongBt = (Button) findViewById(id.liandong_bt);
    	
//    	hongwaiBt.setOnClickListener(this);
//    	yanwuBt.setOnClickListener(this);
//    	zhendongBt.setOnClickListener(this);
//    	liandongBt.setOnClickListener(this);
    	
    	 timer_wd.schedule(task_wd, 1000, 1000);
         UpdateUi();
    }
	Handler handler_wd = new Handler() {  
	   	  public void handleMessage(Message msg) {  
	   	       if(msg.what==0){
	   	    	UpdateUi();
	   	       }  
	   	       super.handleMessage(msg);  
	   	  };  
	};  
	    
	 Timer timer_wd = new Timer();  
	 TimerTask task_wd = new TimerTask() {  
	   	  
	   	  @Override  
	   	   public void run() {  
	   	            // ��Ҫ������:������Ϣ   
	   	      Message message = new Message();   
	   		  
	   			  message.what = 0;  
	   		  
	   		  handler_wd.sendMessage(message);  
	   	    }  
	   	
	   };
	   private void UpdateUi(){
		  
	   }
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
//		case R.id.hongwai_bt:
//			if(Util.hongwaiNum==0){
//				hongwaiImg.setImageResource(R.drawable.design_toggle_on);
//				hongwaiBt.setText("�ر�");
//				Util.hongwaiNum = 1;
//			}else{
//				hongwaiImg.setImageResource(R.drawable.design_toggle_off);
//				hongwaiBt.setText("kaiqi");
//				Util.hongwaiNum = 0;
//			}
//			break;
//		case R.id.yanwu_bt:
//			if(Util.yanwuNum==0){
//				yanwuImg.setImageResource(R.drawable.design_toggle_on);
//				yanwuBt.setText("�ر�");
//				Util.yanwuNum = 1;
//			}else{
//				yanwuImg.setImageResource(R.drawable.design_toggle_off);
//				yanwuBt.setText("����");
//				Util.yanwuNum = 0;
//			}
//			break;
//		case R.id.zhendong_bt:
//			if(Util.zhendongNum==0){
//				zhendongImg.setImageResource(R.drawable.design_toggle_on);
//				zhendongBt.setText("�ر�");
//				Util.zhendongNum = 1;
//			}else{
//				zhendongImg.setImageResource(R.drawable.design_toggle_off);
//				zhendongBt.setText("����");
//				Util.zhendongNum = 0;
//			}
//			break;
//		case R.id.liandong_bt:
//			if(Util.liandongNum==0){
//				liandongImg.setImageResource(R.drawable.design_toggle_on);
//				liandongBt.setText("�ر�");
//				Util.liandongNum = 1;
//			}else{
//				liandongImg.setImageResource(R.drawable.design_toggle_off);
//				liandongBt.setText("����");
//				Util.liandongNum = 0;
//			}
//			break;
		}
	}
	 @Override
	protected void onResume() {
			    	//����Ϊ��activity��handler
			    	//Util.uiHandler = myHandler;
			    	//Util.whichBlock = "B1";
			    	super.onResume();
    }
    private void sendMsgToService(int datas[],int what){
	  if(MainZigBeeService.myHandler!=null){
		Message msg = Message.obtain();
		msg.what = what;
		msg.obj = datas;
		MainZigBeeService.myHandler.sendMessage(msg);
	  }else{
		showMsg("����δ��������������û���豸����");
	  }
	}
	public void showMsg(String text){
		Toast.makeText(this, text,200).show();
	} 
}
