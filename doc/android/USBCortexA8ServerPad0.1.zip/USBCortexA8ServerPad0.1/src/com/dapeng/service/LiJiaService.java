
package com.dapeng.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import com.dapeng.activity.AutoActivity;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;


@SuppressLint("HandlerLeak")
public class LiJiaService extends Service{
	public static boolean ljstart = false;
	String time;
	int addr1 = 0,addr2 = 0;//A6���ӵ����ڵ�ַ
	int addr3 = 0,addr4 = 0;//A8���ӵ����ڵ�ַ
	boolean hongwai = false;
	boolean yawu = false ;
	boolean zhendong = false;
	boolean liandong = false;
	Handler myHandler = new Handler(){
			public void handleMessage(android.os.Message msg) {
				switch (msg.what) {
				case Util.ALLDATA:
					
					break;
				case Util.FDDATA:
					String msg1[]= msg.obj.toString().split(" ");
					if(msg1[4].equals("A6")){//
						parseData_hongwai(msg1);
					}else if(msg1[4].equals("A8")){//
						parseData_yanwu(msg1);
					}
					break;
				case Util.NETNUM:
					break;
				}
			}
	};
		
	//A6��������
	private void parseData_hongwai(String dataStr[]){
		byte data[] = HexDump.hexStringToByteArray(dataStr[17]+dataStr[18]);
  		addr1 = data[0];
  		addr2 = data[1];
		if(dataStr[5].equals("4E") || dataStr[6].equals("4E") || dataStr[7].equals("4E") || dataStr[8].equals("4E")){
			int b[]={addr1,addr2,0xA6,0x46,0x46,0x46,0x46};
			sendMsgToService(b,Util.DSONE5OPEN);
			
		}	
			
	}
	//A8��������
	private void parseData_yanwu(String []dataStr){
		byte data[] = HexDump.hexStringToByteArray(dataStr[17]+dataStr[18]);
  		addr3 = data[0];
  		addr4 = data[1];
		if(dataStr[5].equals("4E") || dataStr[6].equals("4E") || dataStr[7].equals("4E") || dataStr[8].equals("4E")){
			int b[]={addr3,addr4,0xA8,0x46,0x46,0x46,0x46};
			sendMsgToService(b,Util.DSONE5OPEN);
			
		}	
			
	}
	
    public void onCreate() {
    	Util.ljHandler = myHandler;
		Util.ljwhichBlock = "showdata";
		ljstart = true;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	System.out.println("onStartCommand");
    	return super.onStartCommand(intent, flags, startId);
    }
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		System.out.println("onBind");
		return null;
	}

	@Override
	public void onDestroy() {
		ljstart = false;
		super.onDestroy();
	}
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
    private void sendMsgToService(int datas[],int what){
			if(MainZigBeeService.myHandler!=null){
					Message msg = Message.obtain();
					msg.what = what;
					msg.obj = datas;
					MainZigBeeService.myHandler.sendMessage(msg);

			}else{
				showMsg("����δ��������������û���豸����");
			}
	}
	    
}
