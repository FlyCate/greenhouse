
package com.dapeng.service;


import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;


@SuppressLint("HandlerLeak")
public class ShiDuService extends Service{
	int jiedian_fengshan = 0x05,jiedian_tianchuang = 0x08,num_open=0,num_close=0;
    int shidu; 
	boolean tianchuang = false;
	boolean fengshan = false;
	public  static Timer timer_sendData = null;
    public  static TimerTask task_sendData = null;
    public static boolean sdService = false;
    public static int sdMin = -1,sdMax = -1;
	Handler myHandler = new Handler(){
			public void handleMessage(android.os.Message msg) {
				switch (msg.what) {
				case Util.ALLDATA:
					
					break;
				case Util.FDDATA:
					String msg1[]= msg.obj.toString().split(" ");
//					System.out.println("����ʪ������="+msg.obj.toString());
					if(msg1[4].equals("09")){
						parseData_sd(msg1);
					}else if(msg1[4].equals("A6")){
						parseData_fengshan(msg1);
					}else if(msg1[4].equals("A1")){
						parseData_tianchuang(msg1);
					}
					break;
				
				}
			}
	};
		
   private void parseData_sd(String dataStr[]){
	   byte sdByte[] = HexDump.hexStringToByteArray(dataStr[5]+dataStr[6]);
		int numInt[] = new int[2];
		numInt[0] = sdByte[0];
		numInt[1] = sdByte[1];
		if(sdByte[0]<0){
			numInt[0] = numInt[0]+256;
		}
		if(numInt[1]<0){
			numInt[1] = numInt[1]+256;
		}
		shidu = numInt[0];
		System.out.println("sdMin="+sdMin);
		System.out.println("sdMin="+sdMax);
		if(shidu<sdMin && (fengshan || tianchuang)){
			startTimer(1);
//			System.out.println("shidu<sdMin");
			
		}	
		if(shidu>sdMax && (fengshan==false || tianchuang==false)){
			startTimer(0);
//			System.out.println("shidu>sdMin");
		}
   }
   private void parseData_fengshan(String dataStr[]){
	   if(dataStr[5].equals("4E")){
			fengshan = true;
		}else if(dataStr[5].equals("46")){
			fengshan = false;
		}	
   }
   private void parseData_tianchuang(String dataStr[]){
	   if(dataStr[5].equals("4F")){
			tianchuang = true;
		}else if(dataStr[5].equals("43")){
			tianchuang = false;
		}	
   }
    
   private void startTimer(final int a){
	   if(timer_sendData==null){
		    		
		    timer_sendData = new Timer();  
		}
		if(task_sendData == null){
		    		
		    task_sendData = new TimerTask() {  
						@Override
				public void run() {
							// TODO Auto-generated method stub
					Message message = new Message();
					if(a==0){
						message.what = 0;  
					}else if(a==1){
						message.what = 1;  
					}
							    
					handler_sendData.sendMessage(message);  
				}      
		    			 
		    			   	
		    };
		}		   
		if(timer_sendData!=null && task_sendData!=null){
		    	timer_sendData.schedule(task_sendData, 300, 300);   
		}
		    			   
		    	
	}
    public static  void  stopTimer(){
		 if(timer_sendData!=null){
		    	timer_sendData.cancel();
		    	timer_sendData = null;
		    	task_sendData = null;
		  }
	}
	Handler handler_sendData = new Handler() {  
		public void handleMessage(Message msg) {  
			if(msg.what==0){
			   	  sendData(0);
			 }else if(msg.what==1){
			   	   sendData(1);
			 }  
			 super.handleMessage(msg);  
	    };  
	};
			 
	 private void sendData(int type){
		 MainZigBeeService.stopTimer();	
		if(type==0){
			 switch(num_open){
			 case 0:
				int datas[] = {jiedian_fengshan,0x0A,0x4B,0x4E,0xAA,0xAA,0xAA};
				sendMsgToService(datas,Util.DSONE5OPEN);
				
				System.out.println("�򿪡�������������");
				 num_open++;
				 break;
			 case 1:
			    int datas1[] = {jiedian_fengshan,0x0A,0x4B,0xAA,0x4E,0xAA,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);
				System.out.println("�򿪡�������������2");
				num_open++;
			    break;
			case 2:
				int datas5[] = {jiedian_tianchuang,0x0A,0x4B,0x4F,0xAA,0xAA,0xAA};
				sendMsgToService(datas5,Util.DSONE5OPEN);
				System.out.println("�򿪡����������촰");
				num_open=0;
				stopTimer();
				break;
			}
		}else if(type==1){
			switch(num_close){
			case 0:
				int datas[] = {jiedian_fengshan,0x0A,0x4B,0x46,0xAA,0xAA,0xAA};
				sendMsgToService(datas,Util.DSONE5OPEN);
				System.out.println("�رա�������������");
				num_close++;
				break;	
			case 1:
				int datas1[] = {jiedian_fengshan,0x0A,0x4B,0xAA,0x46,0xAA,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);
				System.out.println("�رա�������������222");
				 num_close++;
				 break;
			case 2:
				int datas5[] = {jiedian_tianchuang,0x0A,0x4B,0x43,0xAA,0xAA,0xAA};
				sendMsgToService(datas5,Util.DSONE5OPEN);
				System.out.println("�رա����������촰");
				num_close=0;
				stopTimer();
			    break;
			}
		}
				
	}
    public void onCreate() {
    	System.out.println("����ʪ�Ⱥ�̨���񡣡�����");
    	sdService = true;
	    Util.sdHandler = myHandler;
	    Util.sdwhichBlock = "showdata";
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	System.out.println("onStartCommand");
    	return super.onStartCommand(intent, flags, startId);
    }
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		System.out.println("onBind");
		return null;
	}
	@Override
	public void onDestroy() {
		Util.sdwhichBlock = null;
		sdService = false;
		stopTimer();
		super.onDestroy();
	}
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
    private void sendMsgToService(int datas[],int what){
			if(MainZigBeeService.myHandler!=null){
					Message msg = Message.obtain();
					msg.what = what;
					msg.obj = datas;
					MainZigBeeService.myHandler.sendMessage(msg);
			}else{
				showMsg("����δ��������������û���豸����");
			}
	}
	    
}
