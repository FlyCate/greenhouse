
package com.dapeng.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import com.dapeng.activity.AutoActivity;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;


@SuppressLint("HandlerLeak")
public class GuangZhaoService extends Service{
	public static boolean isstart = false;
	public static double guangzhao=0;
	String time;
	int jiedian_led = 0x06,jiedian_zheyangzhao = 0x0A,num_open=0,num_close=0;
	boolean hongwai = false;
	boolean yawu = false ;
	boolean led = false;
	boolean zheyangzhao = false;
	public  static Timer timer_sendData = null;
    public  static TimerTask task_sendData = null;
    public static boolean gzService = false;
    public static int gzMin = -1,gzMax = -1;
	Handler myHandler = new Handler(){
			public void handleMessage(android.os.Message msg) {
				switch (msg.what) {
				case Util.ALLDATA:
					
					break;
				case Util.FDDATA:
					String msg1[]= msg.obj.toString().split(" ");
					if(msg1[4].equals("02")){
						parseData_gz(msg1);
					}else if(msg1[4].equals("A7")){
						parseData_led(msg1);
					}else if(msg1[4].equals("A3")){
						parseData_zheyangzhao(msg1);
					}
					break;
				case Util.NETNUM:
					System.out.println("msg.obj="+msg.obj);
					break;
				}
			}
	};
		
	//���ն�����
	private void parseData_gz(String dataStr[]){
		byte gzByte[] = HexDump.hexStringToByteArray(dataStr[5]+dataStr[6]);
		int numInt[] = new int[2];
		numInt[0] = gzByte[0];
		numInt[1] = gzByte[1];
		if(gzByte[0]<0){
			numInt[0] = numInt[0]+256;
		}
		if(numInt[1]<0){
			numInt[1] = numInt[1]+256;
		}
		guangzhao = numInt[0]*256+numInt[1];
		System.out.println("guangzhao="+guangzhao);
		System.out.println("AutoActivity.gzMin="+gzMin);
		if(guangzhao<gzMin && (led==false || zheyangzhao==false)){
			stopTimer();
			startTimer(0);
			
		}	
		if(guangzhao>gzMax && (led || zheyangzhao)){
			stopTimer();
			startTimer(1);
			
		}
			
	}
	
    private void startTimer(final int a){
    	if(timer_sendData==null){
    		
    		 timer_sendData = new Timer();  
    	}
    	if(task_sendData == null){
    		
    		 task_sendData = new TimerTask() {  
    			

				@Override
				public void run() {
					// TODO Auto-generated method stub
					  Message message = new Message();
					  if(a==0){
						  message.what = 0;  
					  }else if(a==1){
						  message.what = 1;  
					  }
					    
					  handler_sendData.sendMessage(message);  
				}      
    			 
    			   	
    	     };
    	}		   
    	if(timer_sendData!=null && task_sendData!=null){
    	    timer_sendData.schedule(task_sendData, 300, 300);   
    	}
    			   
    	
    }
    public static  void  stopTimer(){
    	if(timer_sendData!=null){
    		timer_sendData.cancel();
    		timer_sendData = null;
    		task_sendData = null;
    	}
    }
    Handler handler_sendData = new Handler() {  
	   	  public void handleMessage(Message msg) {  
	   	       if(msg.what==0){
	   	         sendData(0);
	   	       }else if(msg.what==1){
	   	    	   sendData(1);
	   	       }  
	   	       super.handleMessage(msg);  
	 };  
	 };
	 
	 private void sendData(int type){
		 MainZigBeeService.stopTimer();	
		 if(type==0){
			 switch(num_open){
			 case 0:
				int datas1[] = {jiedian_led,0x0A,0x4B,0x4E,0xAA,0xAA,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);
				 num_open++;
				 break;
			 case 1:
				 int datas2[] = {jiedian_led,0x0A,0x4B,0xAA,0x4E,0xAA,0xAA};
				 sendMsgToService(datas2,Util.DSONE5OPEN);
				 num_open++;
				 break;
			 case 2:
				 int datas5[] = {jiedian_zheyangzhao,0x0A,0x4B,0x43,0xAA,0xAA,0xAA};
				 sendMsgToService(datas5,Util.DSONE5OPEN);
				 num_open=0;
				 stopTimer();
				 break;
			 }
		 }else if(type==1){
			 switch(num_close){
			 case 0:
				int datas1[] = {jiedian_led,0x0A,0x4B,0x46,0xAA,0xAA,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);
				 num_close++;
				 break;
			 case 1:
				 int datas2[] = {jiedian_led,0x0A,0x4B,0xAA,0x46,0xAA,0xAA};
				 sendMsgToService(datas2,Util.DSONE5OPEN);
				 num_close++;
				 break;
			 case 2:
				 int datas5[] = {jiedian_zheyangzhao,0x0A,0x4B,0x4F,0xAA,0xAA,0xAA};
				 sendMsgToService(datas5,Util.DSONE5OPEN);
				 num_close=0;
				 stopTimer();
				 break;
			 }
		 }
		
	 }
	//����������
	private void parseData_led(String dataStr[]){
		if(dataStr[5].equals("4E")){
			led = true;
		}else if(dataStr[5].equals("46")){
			led = false;
		}	
			
	}
	//����������
	private void parseData_zheyangzhao(String dataStr[]){
		if(dataStr[5].equals("4F")){
			zheyangzhao = true;
		}else if(dataStr[5].equals("43")){
			zheyangzhao = false;
		}	
			
	}
    public void onCreate() {
    	gzService = true;
    	System.out.println("gangzhaoService.......");
    	Util.gzHandler = myHandler;
		Util.gzwhichBlock = "showdata";
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	System.out.println("onStartCommand");
    	return super.onStartCommand(intent, flags, startId);
    }
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		System.out.println("onBind");
		return null;
	}

	@Override
	public void onDestroy() {
		Util.gzwhichBlock = null;
		gzService = false;
		stopTimer();
		super.onDestroy();
	}
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
    private void sendMsgToService(int datas[],int what){
			if(MainZigBeeService.myHandler!=null){
					Message msg = Message.obtain();
					msg.what = what;
					msg.obj = datas;
					MainZigBeeService.myHandler.sendMessage(msg);

			}else{
				showMsg("����δ��������������û���豸����");
			}
	}
	    
}
