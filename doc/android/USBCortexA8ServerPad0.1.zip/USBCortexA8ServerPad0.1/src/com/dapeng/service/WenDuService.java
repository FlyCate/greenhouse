
package com.dapeng.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import com.dapeng.activity.AutoActivity;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;


@SuppressLint("HandlerLeak")
public class WenDuService extends Service{
	int jiedian_jiarebeng = 0x07,jiedian_tianchuang = 0x08,num_open=0,num_close=0;
    int wendu; 
	boolean tianchuang = false;
	boolean jiarebeng = false;
	public  static Timer timer_sendData = null;
    public  static TimerTask task_sendData = null;
    public static boolean wdService = false;
    public static int wdMin = -1,wdMax = -1;
	Handler myHandler = new Handler(){
			public void handleMessage(android.os.Message msg) {
				switch (msg.what) {
				case Util.ALLDATA:
					
					break;
				case Util.FDDATA:
					String msg1[]= msg.obj.toString().split(" ");
					if(msg1[4].equals("09")){
						parseData_wd(msg1);
					}else if(msg1[4].equals("A8")){
						parseData_jiareqi(msg1);
					}else if(msg1[4].equals("A1")){
						parseData_tianchuang(msg1);
					}
					break;
				case Util.NETNUM:
					
					break;
				}
			}
		};
		
		//���ⱨ��һ�δ�����������
	private void parseData_wd(String dataStr[]){
			byte wdByte[] = HexDump.hexStringToByteArray(dataStr[5]+dataStr[6]);
			int numInt[] = new int[2];
			numInt[0] = wdByte[0];
			numInt[1] = wdByte[1];
			if(wdByte[0]<0){
				numInt[0] = numInt[0]+256;
			}
			if(numInt[1]<0){
				numInt[1] = numInt[1]+256;
			}
			wendu = numInt[0]-20;
			
			if(wendu<wdMin && (jiarebeng==false || tianchuang==false)){
				startTimer(0);
				
			}	
			if(wendu>wdMax && (jiarebeng || tianchuang)){
				startTimer(1);
				
			}
			

		}
	//����������
	private void parseData_jiareqi(String dataStr[]){
			if(dataStr[5].equals("4E")){
				jiarebeng = true;
			}else if(dataStr[5].equals("46")){
				jiarebeng = false;
			}			
					

	}
   //�촰
	private void parseData_tianchuang(String dataStr[]){
					
			if(dataStr[5].equals("4F")){
				tianchuang = true;
			}else if(dataStr[5].equals("43")){
				tianchuang = false;
			}			

		}
	private void startTimer(final int a){
	   if(timer_sendData==null){
		    		
		    timer_sendData = new Timer();  
		}
		if(task_sendData == null){
		    		
		    task_sendData = new TimerTask() {  
						@Override
				public void run() {
							// TODO Auto-generated method stub
					Message message = new Message();
					if(a==0){
						message.what = 0;  
					}else if(a==1){
						message.what = 1;  
					}
							    
					handler_sendData.sendMessage(message);  
				}      
		    			 
		    			   	
		    };
		}		   
		if(timer_sendData!=null && task_sendData!=null){
		    	timer_sendData.schedule(task_sendData, 300, 300);   
		}
		    			   
		    	
	}
    public static  void  stopTimer(){
		 if(timer_sendData!=null){
		    	timer_sendData.cancel();
		    	timer_sendData = null;
		    	task_sendData = null;
		  }
	}
	Handler handler_sendData = new Handler() {  
		public void handleMessage(Message msg) {  
			if(msg.what==0){
			   	  sendData(0);
			 }else if(msg.what==1){
			   	   sendData(1);
			 }  
			 super.handleMessage(msg);  
	    };  
	};
			 
	 private void sendData(int type){
		 MainZigBeeService.stopTimer();	
		if(type==0){
			 switch(num_open){
			 case 0:
				int datas1[] = {jiedian_jiarebeng,0x0A,0x4B,0x4E,0xAA,0xAA,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);
				 num_open++;
				 break;
			case 1:
				int datas5[] = {jiedian_tianchuang,0x0A,0x4B,0x4F,0xAA,0xAA,0xAA};
				sendMsgToService(datas5,Util.DSONE5OPEN);
				num_open=0;
				stopTimer();
				break;
			}
		}else if(type==1){
			switch(num_close){
			case 0:
				int datas1[] = {jiedian_jiarebeng,0x0A,0x4B,0x46,0xAA,0xAA,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);
				num_close++;
				break;					
			case 1:
				int datas5[] = {jiedian_tianchuang,0x0A,0x4B,0x43,0xAA,0xAA,0xAA};
				sendMsgToService(datas5,Util.DSONE5OPEN);
				num_close=0;
				stopTimer();
			    break;
			}
		}
				
	}
    public void onCreate() {
    	wdService = true;
	    Util.wdHandler = myHandler;
	    Util.wdwhichBlock = "showdata";
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	return super.onStartCommand(intent, flags, startId);
    }
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onDestroy() {
		Util.wdwhichBlock = null;
		wdService = false;
		super.onDestroy();
	}
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
    private void sendMsgToService(int datas[],int what){
			if(MainZigBeeService.myHandler!=null){
//				if(a){
					Message msg = Message.obtain();
					msg.what = what;
					msg.obj = datas;
					MainZigBeeService.myHandler.sendMessage(msg);
//                    showMsg(anniu);
                   
//				}else{
//					showMsg("�޷���ȡ������ư�����ڵ�ַ���������ڸð�δ����");
//				}
			}else{
				showMsg("����δ��������������û���豸����");
			}
	}
}
