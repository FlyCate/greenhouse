
package com.dapeng.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import com.dapeng.activity.AutoActivity;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.util.HexDump;


@SuppressLint("HandlerLeak")
public class TuRangSDService extends Service{
	int jiedian_shuibeng = 0x07,num_open=0,num_close;
    int trsd; 
	boolean shuibeng = false;
	public  static Timer timer_sendData = null;
    public  static TimerTask task_sendData = null;
    public static boolean trsdService = false;
    public static int trsdMin = -1,trsdMax = -1;
	Handler myHandler = new Handler(){
			public void handleMessage(android.os.Message msg) {
				switch (msg.what) {
				case Util.ALLDATA:
					
					break;
				case Util.FDDATA:
					String msg1[]= msg.obj.toString().split(" ");
					if(msg1[4].equals("09")){
						parseData_wd(msg1);
					}else if(msg1[4].equals("A8")){
						parseData_shuibeng(msg1);
					}
					break;
				case Util.NETNUM:
					System.out.println("msg.obj="+msg.obj);
					break;
				}
			}
	};
	//���ⱨ��һ�δ�����������
	private void parseData_wd(String dataStr[]){
			byte trsdByte[] = HexDump.hexStringToByteArray(dataStr[5]+dataStr[6]);
			int numInt[] = new int[2];
			numInt[0] = trsdByte[0];
			numInt[1] = trsdByte[1];
			if(trsdByte[0]<0){
				numInt[0] = numInt[0]+256;
			}
			if(numInt[1]<0){
				numInt[1] = numInt[1]+256;
			}
			trsd = numInt[0];
			
			if(trsd<trsdMin && shuibeng==false){
				startTimer(0);
				
			}	
			if(trsd>trsdMax && shuibeng){
				startTimer(1);
				
			}
			

		}
	//ˮ������
	private void parseData_shuibeng(String dataStr[]){
			if(dataStr[7].equals("4E")){
				shuibeng = true;
			}else if(dataStr[7].equals("46")){
				shuibeng = false;
			}			
					

	}
   
	private void startTimer(final int a){
		   if(timer_sendData==null){
			    		
			    timer_sendData = new Timer();  
			}
			if(task_sendData == null){
			    		
			    task_sendData = new TimerTask() {  
							@Override
					public void run() {
								// TODO Auto-generated method stub
						Message message = new Message();
						if(a==0){
							message.what = 0;  
						}else if(a==1){
							message.what = 1;  
						}
								    
						handler_sendData.sendMessage(message);  
					}      
			    			 
			    			   	
			    };
			}		   
			if(timer_sendData!=null && task_sendData!=null){
			    	timer_sendData.schedule(task_sendData, 300, 300);   
			}
			    			   
			    	
		}
	    public static  void  stopTimer(){
			 if(timer_sendData!=null){
			    	timer_sendData.cancel();
			    	timer_sendData = null;
			    	task_sendData = null;
			  }
		}
		Handler handler_sendData = new Handler() {  
			public void handleMessage(Message msg) {  
				if(msg.what==0){
				   	  sendData(0);
				 }else if(msg.what==1){
				   	   sendData(1);
				 }  
				 super.handleMessage(msg);  
		    };  
		};
				 
		 private void sendData(int type){
			 MainZigBeeService.stopTimer();	
			if(type==0){
				int datas1[] = {jiedian_shuibeng,0x0A,0x4B,0xAA,0xAA,0x4E,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);		
			}else if(type==1){				
				int datas1[] = {jiedian_shuibeng,0x0A,0x4B,0xAA,0xAA,0x46,0xAA};
				sendMsgToService(datas1,Util.DSONE5OPEN);
				
			}
					
		}
	    public void onCreate() {
	    	trsdService = true;
		    Util.trsdHandler = myHandler;
		    Util.trsdwhichBlock = "showdata";
	    }
	    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	System.out.println("onStartCommand");
    	return super.onStartCommand(intent, flags, startId);
    }
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		System.out.println("onBind");
		return null;
	}

	@Override
	public void onDestroy() {
		Util.trsdwhichBlock = null;
		super.onDestroy();
	}
	//datas��˳�� 1�����ڵ�ַ1 2�����ڵ�ַ2  3�����ӽڵ�  4����Դ�ڵ�  5��������Ϣ1  6��������Ϣ2 7��������Ϣ3
    private void sendMsgToService(int datas[],int what){
			if(MainZigBeeService.myHandler!=null){
					Message msg = Message.obtain();
					msg.what = what;
					msg.obj = datas;
					MainZigBeeService.myHandler.sendMessage(msg);

			}else{
				showMsg("����δ��������������û���豸����");
			}
	}
	    
}
