
package com.dapeng.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.dapeng.R;
import com.dapeng.util.Util;
import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.util.HexDump;
import com.hoho.android.usbserial.util.SerialInputOutputManager;


@SuppressLint("HandlerLeak")
public class MainZigBeeService extends Service{
	//���ڵ�ַ
//	public static int addr1,addr2;
    private final String TAG = MainZigBeeService.class.getSimpleName();
    public static UsbSerialDriver sDriver = null;
//    public static String whichBlock = "30";//�������˲�ͬ�İ����ź�  Ĭ����30
    private String netNumStr = "",singelNumStr = "";
    boolean isRead = true;
    boolean isUploadBoxNum = false;
    int boxnum = 0;
    int num=0,FDNum=0,lunxunNum = 1;
    boolean isLanYa=false;
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
    private SerialInputOutputManager mSerialIoManager;
    public static Timer timer_lunxun = null;
    public static TimerTask task_lunxun = null;
    public static int typeNum = 0;
    public static Handler myHandler;//����������ƺ�̨��handler
    public void onCreate() {
    	myHandler =new Handler(){//����������ƺ�̨��handler
        	public void handleMessage(android.os.Message msg) {
        		switch (msg.what) {
    			case Util.STOP:
    				stopIoManager();
    				break;
    			case Util.START:
    				startIoManager();
    				break;
    			case Util.RESTART:
    				onDeviceStateChange();
    				break;
    			case Util.STOPALL:
    				MainZigBeeService.this.stopSelf();
    				break;
    			case Util.CLOSELIGHT:
    				sendByte(Util.addr1,Util.addr2,0x30,0x01,('N' & 0xff),(0 & 0xff),0xAA);
    				break;
    			case Util.OPENLIGHT:
    				sendByte(Util.addr1,Util.addr2,0x30,0x01,('F' & 0xff),(0 & 0xff),0xAA);
    				break;
    			case Util.CHANGECANSHU:
    				setRateAndMore();
    				break;
    			case Util.DSONE1OPEN:
    			case Util.DSONE2OPEN2:
    			case Util.DSONE2BT1:
    			case Util.DSONE2BT2:
    			case Util.DSONE2BT3:
    			case Util.DSONE2OPEN1:
    			case Util.DSONE3OPEN:
    			case Util.DSONE5OPEN:
    				
    			case Util.DSTWO1OPEN:
    			case Util.DSTWO1QUEDING:
    			case Util.DSTWO4OPEN:	
    			case Util.DSTWO5OPEN:
    				sendToBlock(msg);
    				break;
    			case Util.WRITEDATA:
    				try {//д����ʽ 1,���ڵ�ַ1 2.���ڵ�ַ2 3�����Ӻ�   4����Դ��� 5��������Ϣ1 6��������Ϣ2 7��������Ϣ3
    					String msgStr = (String)msg.obj;
    					String msgs[] = msgStr.split(" ");
//    					int length = msgs.length;
    					byte data[] = new byte[7];
    					data[6] = (byte) 0xAA;
    					data[5] = (byte) 0xAA;
    					data[4] = (byte) 0xAA;
    					data[3] = (byte) 0xAA;
    					data[2] = (byte) 0xAA;
    					data[1] = (byte) 0xAA;
    					data[0] = (byte) 0xAA;
    					for(int i=0;i<msgs.length;i++){
    						data[i] = HexDump.hexStringToByteArray(msgs[i])[0];
//    						data[i] = (byte)msgs[i].charAt(0);
    						System.out.println("data["+i+"] ="+data[i]);
    					}
    					//������Ϣ
    					sendByte(data[0],data[1],data[2],data[3],data[4],data[5],data[6]);
    					} catch (Exception e) {
						e.printStackTrace();
					}
    				break;
    			}
        	}
        };
        start();
        startTimer();
        
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	//ÿ��������������������ò�����ˢ�¸��ֲ���
    	setRateAndMore();
    	return super.onStartCommand(intent, flags, startId);
    }

    private final SerialInputOutputManager.Listener mListener =
            new SerialInputOutputManager.Listener() {
        @Override
        public void onRunError(Exception e) {
            Log.d(TAG, "onRunError");
        }
        @Override
        public void onNewData(final byte[] data) {
            new Thread(){
            	public void run(){
                    MainZigBeeService.this.updateReceivedData(data);
                }
            }.start();
        }
    };
    
    private void sendToBlock(Message msg){
    	int datas1[] = (int [])msg.obj;
		if(datas1!=null){
			sendByte(datas1[0],datas1[1],datas1[2],datas1[3],datas1[4],datas1[5],datas1[6]);
		}
    }
    Handler handler_lunxun = new Handler() {  
	   	  public void handleMessage(Message msg) {  
	   	       if(msg.what==0){
	   	         lunxun();
	   	       }  
	   	       super.handleMessage(msg);  
	 };  
	 }; 
	 private void lunxun(){
		     int jiedian = 0;       // ��Ҫ������:������Ϣ   
		     if(typeNum==0){
		    	 switch(lunxunNum){
		   	     case 1:
		   	    	 jiedian = 0x01;
		   	    	 lunxunNum++;
		   	    	 break;
		   	     case 2:
		   	    	 jiedian = 0x02;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 3:
		   	    	 jiedian = 0x03;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 4:
		   	    	 jiedian = 0x04;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 5:
		   	    	 jiedian = 0x05;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 6:
		   	    	 jiedian = 0x06;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 7:
		   	    	 jiedian = 0x07;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 8:
		   	    	 jiedian = 0x08;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 9:
		   	    	 jiedian = 0x09;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 10:
		   	    	 jiedian = 0x0A;
		   	    	lunxunNum++;
		   	    	 break;
		   	     case 11:
		   	    	 jiedian = 0x0B;
		   	    	lunxunNum=1;
		   	    	 break;
		   	    	
		   	     }
		   	   
		   	     byte data[] = {(byte) 0xFE,(byte) jiedian,(byte)0x04,(byte)0x43,(byte) 0xCC,(byte) 0xFB};
		   	     writeData(data); 
		     }
	   	    
	 }
    private void startTimer(){
    	if(timer_lunxun==null){
    		
    		 timer_lunxun = new Timer();  
    	}
    	if(task_lunxun == null){
    		
    		 task_lunxun = new TimerTask() {  
    			

				@Override
				public void run() {
					// TODO Auto-generated method stub
					  Message message = new Message();
					  message.what = 0;  
					  handler_lunxun.sendMessage(message);  
				}      
    			 
    			   	
    	     };
    	}		   
    	if(timer_lunxun!=null && task_lunxun!=null){
    	    timer_lunxun.schedule(task_lunxun, 300, 300);   
    	}
    			   
    	
    }
    public static void  stopTimer(){
    	if(timer_lunxun!=null){
    		timer_lunxun.cancel();
    		timer_lunxun = null;
    		task_lunxun = null;
    	}
    }
   
    //д������ ��Ҫƴ�� sDriver.write(sendByte(addr1,addr2,0x01,('N' & 0xff),(0 & 0xff)), 100);
    private byte[] sendByte(int jiedian,int length,int ck,int data1,int data2,int data3,int data4){
        byte[] linedata = new byte[12];
        //֡ͷ
        linedata[0] = (byte) (0xFE);
        linedata[1] = (byte) (jiedian);
        //���ݳ���
        linedata[2] = (byte) (length);
        //��/��
        linedata[3] = (byte) (ck);
        //�ڵ�
      //������Ϣ
        linedata[4] = (byte) (data1);
        linedata[5] = (byte) (data2);
        linedata[6] = (byte) (data3);
        linedata[7] = (byte) (data4);
        linedata[8] = (byte) (0xAA);
        linedata[9] = (byte) (0xAA);
        //���У��
        linedata[10] = (byte) (0xCC);
        //֡β
        linedata[11] = (byte) (0xFB);
        writeData(linedata);
        return linedata;
    }
    
    public void writeData(byte linedata[]){
    	 
        try {
        	if (sDriver != null) {
        		if(linedata.length>10){
        			stopTimer();
            		sDriver.write(linedata,100);
            		//System.out.println("�������ݡ���������"+linedata[4]);
            	

            		startTimer();
        		}
        		else{
        			sDriver.write(linedata,100);
        			//System.out.println("��ѯ���ݡ���������");
        		}
//        		for(int i=0;i<linedata.length;i++){
//        			System.out.println("���ݡ���������"+linedata[i]);
//        		}
        		
        	}else{
        		showMsg("�޷�������Ϣ��û���ҵ��豸����...");
        	}
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

    protected void stop() {
        stopIoManager();
        if (sDriver != null) {
            try {
                sDriver.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            sDriver = null;
        }
        if(upLoadThread!=null&&upLoadThread.isAlive()){
        	
		}
    }
    
    private void setRateAndMore(){//����rate ���ֲ���
        try {
                if(sDriver!=null){
                    sDriver.setParameters(Util.rate, Util.dataBits,Util.stopBit, Util.jiou);
                }
            } catch (IOException e) {
            	e.printStackTrace();
            }
    }
    
    protected void start() {
        Log.d(TAG, "Resumed, sDriver=" + sDriver);
        if (sDriver == null) {
            showMsg("û���豸,������豸");
        } else {
            try {
                sDriver.open();
                //115200  38400,8, UsbSerialDriver.STOPBITS_1
                sDriver.setParameters(Util.rate, 8, UsbSerialDriver.STOPBITS_1, UsbSerialDriver.PARITY_NONE);
            } catch (IOException e) {
                Log.e(TAG, "�����豸����: " + e.getMessage(), e);
                showMsg("�����豸����: " + e.getMessage());
                try {
                    sDriver.close();
                } catch (IOException e1) {
                	e1.printStackTrace();
                }
                sDriver = null;
                return;
            }
        }
        
        onDeviceStateChange();
    }

    //ֹͣ��usb��ȡ����
    private void stopIoManager() {
        if (mSerialIoManager != null) {
            Log.i(TAG, "����ֹͣ manager ..");
            mSerialIoManager.stop();
            mSerialIoManager = null;
        }
    }

    //��ʼ��USB��ȡ����
    private void startIoManager() {
        if (sDriver != null) {
            Log.i(TAG, "��������  manager ..");
            mSerialIoManager = new SerialInputOutputManager(sDriver, mListener);
            mExecutor.submit(mSerialIoManager);
        }
    }

    //����
    private void onDeviceStateChange() {
        stopIoManager();
        startIoManager();
    } 

    //�������յ������ݣ����յ������ݿ����ǵ�����  ����Ҫһ����ʾ21�� �����ڴ�ƴ�ӣ�������Ӧ������  ��������͵�ǰ̨����
    int labelCount = 0;
    StringBuilder sb = new StringBuilder();
    StringBuilder sbl = new StringBuilder();
    private synchronized void updateReceivedData(byte[] data) {
        if(isRead){
        	String s = HexDump.dumpHexString(data);
        	//System.out.println("Э�������ݣ�"+s);
        	
	        			 if(sb.length() == 0){
	        	        		if(!s.startsWith("F") && !s.startsWith("55")){
	        	        			return;
	        	        		}
	        	        	}
	        			 sb.append(s);
	        	         if(sb.length()>=63){
	        	        		String recStr ="";
	        	        		if(sb.length()==63){
	        	        			recStr = sb.toString();
	        	        			sb.delete(0, sb.length());
	        	        		}else{
	        	        			recStr = sb.substring(0, 63);
	        	        			sb.delete(0, sb.length());
	        	        		}
	        	        		getAddreAndSendToUI(recStr);	
	        	         }
	       }	        	 

    }
    
//    int i= 0;
    String strUrl = Util.IP+"rdf?bn="+boxnum;//�ϴ����ӱ��
    Runnable  runUpLoadThread  = new Runnable(){
		public void run(){
	    	try {
	    		byte msg[] = uploadStr.getBytes("UTF-8");
	    		System.out.println("msg.length  "+msg.length);
	    		
//	    		String strUrl = "http://192.168.2.69:8083/wlw/padUpLoad?name="+netNumStr;//�ϴ����ӱ��
//	    		String strUrl = "http://192.168.2.69:8083/WEBUpLoadFileTest/test?name="+netNumStr;//�ϴ����ӱ��
	    		//System.out.println("���󡣡�"+strUrl);
	    		URL url = new URL(strUrl);
	    		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	    		//����ʽ
	    		conn.setRequestMethod("POST");
	    		conn.setConnectTimeout(5*1000);
	    		//������������д��
	    		conn.setDoOutput(true);
	    		//�������������� ������ı����԰�application/soapȥ���򻻳�text
	    		conn.setRequestProperty("Content-Type", "application/soap,charset=utf-8");
	    		//�����ı�ʱ��ô��ϳ���  û��Ҳ�ܷ��ͳɹ�
	    		conn.setRequestProperty("Content-Length", String.valueOf(msg.length));
	    		OutputStream os = conn.getOutputStream();
	    		os.write(msg);
	    		os.flush();
	    		os.close();
	    		if(conn.getResponseCode() == 200){
		    		byte b[] = inputStream2Bytes(conn.getInputStream());
		    		System.out.println("b.size = "+b.length);
		    		String recMsg = new String(b, "UTF-8");
		    		recMsg = recMsg.trim();
		    		System.out.println("recMsg  :"+recMsg+"    "+recMsg.startsWith("FE"));
		    		if(recMsg.startsWith("FE")||recMsg.startsWith("FC")){//�ж϶��������ΪFE ��ʽ������
		    			recMsg=recMsg.replaceAll(" ", "");//��Ҫ�Ƴ��ո���ת��Ϊ�ֽ�����
		    			byte sendBytes[] = HexDump.hexStringToByteArray(recMsg);
		    			//System.out.println("sendBytes.length  "+sendBytes.length);
		    			writeData(sendBytes);//��zigbeeд��ȥ
		    			System.out.println("write out="+recMsg);
		    		}
	    		}
	    		conn.disconnect();
	    	} catch (Exception e) {
	    		e.printStackTrace();
	    	}
		}
	};
    StringBuilder sbSend = new StringBuilder();
    String uploadStr = "";
    Thread upLoadThread =null;
    private void postToHttp(String str){
    	if(Util.isConnect(this)&&netNumStr.length()>0){
	    	sbSend.append(str+"\r\n");
	    	if(sbSend.toString().length()>300){
	    		uploadStr = new String(sbSend.toString());
	    		sbSend.delete(0, sbSend.length());
	    		upLoadThread = new Thread(runUpLoadThread);
	    		if(!upLoadThread.isAlive()){
	    			upLoadThread.start();
	    		}
	    	}
    	}
    }
    //�ͻ��˺ͷ�������Ҫ�õ��Ķ�ȡ������
    public byte[] inputStream2Bytes(InputStream inStream) {
    	ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
    	byte[] buff = new byte[1024];
    	int rc = 0;
    	try {
    		while ((rc = inStream.read(buff, 0, 1024)) > 0) {
    			swapStream.write(buff, 0, rc);
    		}
    		inStream.close();
    		return swapStream.toByteArray();
    	} catch (IOException e) {
    		e.printStackTrace();
    		return null;
    	}
    }
    
    private void sendMsgToUI(Object obj,int what){
    	if(Util.uiHandler!=null){
    		Message msg = Message.obtain();
    		msg.what = what;
    		msg.obj = obj;
    		Util.uiHandler.sendMessage(msg);
    	}
     }
    Handler timer = new Handler(){
    	public void handleMessage(Message msg) {
    			sendMsgToUI("null",Util.NETADRR);
    	}
    };
    //�ӻ�ȡ���������еõ�������ַ ����� �ŵ���
    private void getAddreAndSendToUI(String s){
        try {
			if(s.length()>60&&s.length()<70){
			   String msg[]= s.split(" ");
			   postToHttp(s);//�ϴ���������
			   
			   if(s.startsWith("FC")){
				   int num = HexDump.hexStringToByteArray(msg[1])[0]+HexDump.hexStringToByteArray(msg[2])[0];
				   netNumStr = num+"";//ʵ������
				   singelNumStr = msg[3]+"";
				   sendMsgToUI(msg[1]+msg[2]+"",Util.NETNUM);
				   sendMsgToUI(singelNumStr,Util.SINGLENUM);
				   sendMsgToUI(s,Util.FCDATA);
				   
				   if(!isUploadBoxNum){
					   boxnum = HexDump.hexStringToByteArray(msg[5])[0]+50;
					   Util.boxNum= boxnum+"";
					   System.out.println("boxnum="+boxnum);
					   strUrl = Util.IP+"rnf?bn="+boxnum+"&netnum="+netNumStr+"&singlenum="+singelNumStr;//�ϴ����ӱ��
					   uploadStr = "";
					   Thread upLoadThread = new Thread(runUpLoadThread);
			    	   upLoadThread.start();
					   isUploadBoxNum = true;
				   }
			   }else 
				if(s.startsWith("FD")){
				   if(msg.length>16){
					   strUrl = Util.IP+"rdf?action=write&bn="+boxnum;//�ϴ����ӱ��
					   if(isUploadBoxNum){//�����Ӻ���ȶ������͵�������֮�����ϴ�����
						   postToHttp(s);//�ϴ���������
					   }
					   if(Util.whichBlock.equals(msg[4])||Util.whichBlock.equals("showdata")){
						   //ʮ�������ַ���תΪʮ��������
//				           byte []bb = HexDump.hexStringToByteArray(msg[17]+msg[18]);
//				           Util.addr1 = bb[0];//ʮ����
//				           Util.addr2 = bb[1];
//				           sendMsgToUI(msg[17]+""+msg[18],Util.NETADRR);
				           sendMsgToUI(s,Util.FDDATA);
				           //��ʱ��û�н��ܵ���������null������������ڵ�ַ
				           timer.removeMessages(0);
				           timer.sendEmptyMessageDelayed(0, 6000);
					   }
					   if(Util.gzwhichBlock.equals(msg[4])||Util.gzwhichBlock.equals("showdata")){
						   //ʮ�������ַ���תΪʮ��������
				           byte []bb = HexDump.hexStringToByteArray(msg[17]+msg[18]);				          
				           sendMsgToGZ(s,Util.FDDATA);
				           //��ʱ��û�н��ܵ���������null������������ڵ�ַ
				           timer.removeMessages(0);
				           timer.sendEmptyMessageDelayed(0, 6000);
					   }
					   if(Util.sdwhichBlock.equals(msg[4])||Util.sdwhichBlock.equals("showdata")){
						   //ʮ�������ַ���תΪʮ��������
				           byte []bb = HexDump.hexStringToByteArray(msg[17]+msg[18]);				          
				           sendMsgToSD(s,Util.FDDATA);
				           //��ʱ��û�н��ܵ���������null������������ڵ�ַ
				           timer.removeMessages(0);
				           timer.sendEmptyMessageDelayed(0, 6000);
					   }
					   if(Util.wdwhichBlock.equals(msg[4])||Util.wdwhichBlock.equals("showdata")){
						   //ʮ�������ַ���תΪʮ��������
				           byte []bb = HexDump.hexStringToByteArray(msg[17]+msg[18]);				          
				           sendMsgToWD(s,Util.FDDATA);
				           //��ʱ��û�н��ܵ���������null������������ڵ�ַ
				           timer.removeMessages(0);
				           timer.sendEmptyMessageDelayed(0, 6000);
					   }
					   if(Util.trsdwhichBlock.equals(msg[4])||Util.trsdwhichBlock.equals("showdata")){
						   //ʮ�������ַ���תΪʮ��������
				           byte []bb = HexDump.hexStringToByteArray(msg[17]+msg[18]);				          
				           sendMsgToTRSD(s,Util.FDDATA);
				           //��ʱ��û�н��ܵ���������null������������ڵ�ַ
				           timer.removeMessages(0);
				           timer.sendEmptyMessageDelayed(0, 6000);
					   }
				   }
			   }
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    private void sendMsgToGZ(Object obj,int what){
 	    if(Util.gzHandler!=null){
 		Message msg = Message.obtain();
 		msg.what = what;
 		msg.obj = obj;
 		Util.gzHandler.sendMessage(msg);
 	   }
     }
    
    private void sendMsgToSD(Object obj,int what){
 	    if(Util.sdHandler!=null){
 		Message msg = Message.obtain();
 		msg.what = what;
 		msg.obj = obj;
 		Util.sdHandler.sendMessage(msg);
 	   }
     }
    private void sendMsgToWD(Object obj,int what){
 	    if(Util.wdHandler!=null){
 		Message msg = Message.obtain();
 		msg.what = what;
 		msg.obj = obj;
 		Util.wdHandler.sendMessage(msg);
 	   }
     }   
    private void sendMsgToTRSD(Object obj,int what){
 	    if(Util.trsdHandler!=null){
 		Message msg = Message.obtain();
 		msg.what = what;
 		msg.obj = obj;
 		Util.trsdHandler.sendMessage(msg);
 	   }
     }
	
    public void showMsg(String text){
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onDestroy() {
		stopTimer();
		stop();
		super.onDestroy();
	}
    
}
